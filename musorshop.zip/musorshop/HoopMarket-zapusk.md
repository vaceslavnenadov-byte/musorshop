# HoopMarket: инструкция по запуску

Имена скриптов на шаге 3 условные: точные даст ассистент на шаге 6 разработки.

## Что нужно установить

- **Node.js** (версия LTS) с nodejs.org
- **MongoDB Community Server**: при установке оставь галочку «Install MongoD as a Service», чтобы база запускалась вместе с Windows
- **VS Code** и **MongoDB Compass** (для просмотра базы, необязательно)

Проверка в PowerShell: `node -v` и `npm.cmd -v` выводят номера версий.

## Первый запуск

**1. Установить пакеты.** В папке `backend`:

```powershell
cd путь\к\проекту\backend
npm.cmd install
```

**2. Создать файл настроек.** Скопируй `backend/.env.example` в `backend/.env` и заполни:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/hoopmarket
JWT_SECRET=длинная_случайная_строка
ADMIN_EMAIL=admin@hoopmarket.ru
ADMIN_PASSWORD=твой_пароль
```

Секрет для `JWT_SECRET` можно получить командой:

```powershell
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

**3. Создать администратора и наполнить каталог** (один раз):

```powershell
node createAdmin.js
node seed.js
```

Должны появиться сообщения о созданном администраторе и добавленных командах, игроках и товарах.

**4. Запустить сервер:**

```powershell
npm.cmd run dev
```

В окне появится `MongoDB подключена` и `Сайт и API запущены: http://localhost:5000`.

**5. Открыть сайт** в браузере: **http://localhost:5000**. Войти под администратором можно с данными из `.env`.

## Последующие запуски

Нужен только пункт 4: перейти в папку `backend` и выполнить `npm.cmd run dev`. Окно терминала держать открытым, пока работаешь с сайтом; остановка — `Ctrl+C`.

## Проверка тестами

Во втором окне терминала, в папке `backend`:

```powershell
npm.cmd test
```

В конце вывода должно быть `fail 0`.

## Частые проблемы

| Сообщение | Причина и решение |
|---|---|
| `npm.ps1 … выполнение сценариев отключено` | Пиши `npm.cmd` вместо `npm` |
| `Could not read package.json` | Команда запущена не в папке `backend` |
| `Не удалось подключиться к MongoDB` | Служба MongoDB не запущена: «Службы» Windows → MongoDB → Запустить |
| `В файле .env не заданы …` | Файл `.env` не создан или лежит не в папке `backend` |
| `EADDRINUSE: … 5000` | Сервер уже запущен в другом окне: закрой его или смени `PORT` |
| Страница пустая, в консоли `404` на скрипт | Файл лежит не в `frontend/js` или назван иначе |

## На сервере

Запуск на VPS делается так же, как с MusorShop: Ubuntu 24.04, Node.js, MongoDB с паролем, сайт как служба `systemd`, веб-сервер Caddy с HTTPS. После настройки сайт запускается сам; основные команды:

```bash
systemctl status hoopmarket     # работает ли
systemctl restart hoopmarket    # перезапуск после обновления кода
journalctl -u hoopmarket -n 50  # журнал
```
