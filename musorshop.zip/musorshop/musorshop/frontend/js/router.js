// router.js
// Экраны: переключение между каталогом, кейсами и личным кабинетом

// ==================== ЭКРАНЫ: КАТАЛОГ И ЛИЧНЫЙ КАБИНЕТ ====================

// Показывает нужный экран в зависимости от адреса:
//   ...index.html           — каталог
//   ...index.html#cases     — кейсы
//   ...index.html#market    — торговая площадка
//   ...index.html#profile   — личный кабинет
function renderRoute() {
  const views = {
    catalog: document.getElementById('catalogView'),
    cases: document.getElementById('casesView'),
    market: document.getElementById('marketView'),
    profile: document.getElementById('profileView')
  };

  const byHash = { '#profile': 'profile', '#cases': 'cases', '#market': 'market' };
  let target = byHash[location.hash] || 'catalog';

  // Кабинет доступен только вошедшему пользователю
  if (target === 'profile' && !currentUser) {
    // Сессия ещё восстанавливается — ждём (refreshUser вызовет нас повторно)
    if (hasSession() && !sessionChecked) return;

    // Гость: убираем #profile из адреса и показываем каталог
    history.replaceState(null, '', location.pathname + location.search);
    target = 'catalog';
  }

  // Какой экран был открыт до этого
  const previous = Object.keys(views).find((name) => !views[name].classList.contains('hidden'));

  Object.keys(views).forEach((name) => {
    views[name].classList.toggle('hidden', name !== target);
  });

  document.title = {
    catalog: 'MusorShop — маркетплейс скинов CS2',
    cases: 'Кейсы — MusorShop',
    market: 'Площадка — MusorShop',
    profile: 'Личный кабинет — MusorShop'
  }[target];

  // Подсветка ссылок в шапке
  [['casesBtn', 'cases'], ['marketBtn', 'market']].forEach(([id, name]) => {
    const link = document.getElementById(id);
    link.classList.toggle('text-yellow-500', target === name);
    link.classList.toggle('text-gray-300', target !== name);
  });

  if (target !== previous) {
    // Экран только что открылся — прокручиваем наверх и загружаем данные
    window.scrollTo({ top: 0, behavior: 'instant' });
    if (target === 'profile') loadProfilePage();
    if (target === 'cases') loadCases();
    if (target === 'market') loadMarket();
  } else if (target === 'cases') {
    // Экран тот же, но мог смениться пользователь — перерисовываем кнопки
    renderCases();
  } else if (target === 'market') {
    loadMarket();
  }
}

// Адрес изменился (клик по ссылке, кнопки "Назад"/"Вперёд" в браузере)
window.addEventListener('hashchange', renderRoute);

// Кнопка "Главная" и логотип возвращают в каталог
function goToCatalog() {
  if (location.hash) {
    location.hash = '';
  }
}

document.getElementById('homeBtn').addEventListener('click', goToCatalog);
document.getElementById('logoLink').addEventListener('click', goToCatalog);

// Фильтр покупок в кабинете
document.getElementById('purchaseFilters').addEventListener('click', (event) => {
  const button = event.target.closest('[data-purchase-filter]');
  if (!button) return;

  purchaseFilter = button.dataset.purchaseFilter;
  renderPurchases();
});
