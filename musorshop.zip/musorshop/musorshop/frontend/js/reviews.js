// reviews.js
// Отзывы и рейтинги товаров

// ==================== ОТЗЫВЫ И РЕЙТИНГИ ====================

let reviewProductId = null;  // товар, отзывы которого сейчас открыты
let currentReviews = [];     // загруженные отзывы этого товара
let selectedRating = 0;      // выбранная в форме оценка (0 = не выбрана)
let editingReviewId = null;  // id редактируемого отзыва (null = пишем новый)

// Загрузка средних рейтингов всех товаров и перерисовка карточек
async function loadRatings() {
  try {
    ratings = await apiRequest('/products/ratings/all');
    renderProducts();
  } catch (err) {
    // не критично: на карточках останется "Нет оценок"
  }
}

// Подсветка звёзд в форме: первые value звёзд жёлтые, остальные серые
function setStarRating(value) {
  selectedRating = value;
  document.querySelectorAll('#starRating .star').forEach((star) => {
    const active = Number(star.dataset.star) <= value;
    star.classList.toggle('text-yellow-500', active);
    star.classList.toggle('text-gray-600', !active);
  });
}

// HTML пяти звёзд для показа оценки в отзыве
function renderStars(rating) {
  let html = '';
  for (let i = 1; i <= 5; i++) {
    html += `<i class="fa-solid fa-star ${i <= rating ? 'text-yellow-500' : 'text-gray-600'}"></i>`;
  }
  return html;
}

// Кнопка "Отмена" для режима редактирования — создаём один раз и добавляем в форму
const cancelEditBtn = document.createElement('button');
cancelEditBtn.type = 'button';
cancelEditBtn.textContent = 'Отмена';
cancelEditBtn.className =
  'hidden w-full py-2.5 rounded-lg bg-gray-800 border border-gray-700 font-medium hover:bg-gray-700 transition';
document.getElementById('reviewForm').appendChild(cancelEditBtn);

// Возврат формы в исходное состояние (режим "новый отзыв")
function resetReviewForm() {
  const form = document.getElementById('reviewForm');
  editingReviewId = null;
  form.reset();
  setStarRating(0);
  form.querySelector('button[type="submit"]').textContent = 'Оставить отзыв';
  cancelEditBtn.classList.add('hidden');
}

// Есть ли открытый товар в истории покупок текущего пользователя
let reviewPurchased = false;

// Показывать ли форму:
// - в режиме редактирования — всегда;
// - иначе только покупателю, который купил товар и ещё не оставлял на него отзыв
function updateReviewFormVisibility() {
  const isBuyer = currentUser && currentUser.role === 'user';
  const alreadyReviewed = isBuyer &&
    currentReviews.some((review) => String(review.userId) === String(currentUser.id));

  const canWrite = isBuyer && !alreadyReviewed && reviewPurchased;
  const visible = editingReviewId !== null || canWrite;
  document.getElementById('reviewFormWrapper').classList.toggle('hidden', !visible);

  // Покупателю, который товар не покупал, объясняем, почему формы нет
  const showHint = isBuyer && !alreadyReviewed && !reviewPurchased && editingReviewId === null;
  document.getElementById('reviewHint').classList.toggle('hidden', !showHint);
}

// Может ли текущий пользователь менять и удалять этот отзыв
function canManageReview(review) {
  if (!currentUser) return false;
  return currentUser.role === 'admin' || String(review.userId) === String(currentUser.id);
}

// Загрузка и отрисовка отзывов открытого товара
async function loadReviews() {
  const list = document.getElementById('reviewsList');
  list.innerHTML = '<p class="text-sm text-gray-500">Загрузка…</p>';

  let data;
  try {
    data = await apiRequest(`/products/${reviewProductId}/reviews`);
  } catch (err) {
    list.innerHTML = '<p class="text-sm text-red-400">Не удалось загрузить отзывы</p>';
    return;
  }

  currentReviews = data.reviews;

  
  // Узнаём у сервера, покупал ли текущий пользователь этот товар
  reviewPurchased = false;
  if (currentUser && currentUser.role === 'user') {
    try {
      const permission = await apiRequest(`/products/${reviewProductId}/can-review`);
      reviewPurchased = permission.purchased;
    } catch (err) {
      // не удалось узнать — форму не показываем, сервер всё равно проверит сам
    }
  }

  // Средний рейтинг и количество
  document.getElementById('reviewsAverage').textContent = data.count > 0 ? data.average : '—';
  document.getElementById('reviewsCount').textContent = data.count;

  updateReviewFormVisibility();

  if (data.count === 0) {
    list.innerHTML = '<p class="text-sm text-gray-500">Отзывов пока нет</p>';
    return;
  }

  list.innerHTML = currentReviews.map((review) => {
    const id = escapeHtml(review.id);

    // Кнопки управления — автору отзыва и админу
    const actions = canManageReview(review)
      ? `<span class="shrink-0 flex gap-1">
           <button type="button" data-review-edit="${id}" title="Изменить" aria-label="Изменить отзыв"
                   class="w-7 h-7 rounded bg-gray-700 text-xs text-blue-400 hover:bg-gray-600">✎</button>
           <button type="button" data-review-delete="${id}" title="Удалить" aria-label="Удалить отзыв"
                   class="w-7 h-7 rounded bg-gray-700 text-xs text-red-400 hover:bg-gray-600">✕</button>
         </span>`
      : '';

    // Пометка об изменении
    const edited = review.editedAt
      ? ` · ${review.editedByAdmin ? 'изменено администратором' : 'изменено'}`
      : '';

    return `
      <div class="bg-gray-800 rounded-lg p-3">
        <div class="flex items-center justify-between gap-2">
          <span class="min-w-0 flex flex-wrap items-center gap-2">
            <span class="text-sm font-medium truncate">${escapeHtml(review.userEmail)}</span>
            ${review.verified
              ? '<span class="px-2 py-0.5 rounded bg-green-600/20 text-green-500 text-xs font-medium">✔ Проверенная покупка</span>'
              : ''}
          </span>
          <span class="shrink-0 flex items-center gap-2">
            <span class="text-xs">${renderStars(review.rating)}</span>
            ${actions}
          </span>
        </div>
        ${review.comment
          ? `<p class="mt-2 text-sm text-gray-300 break-words">${escapeHtml(review.comment)}</p>`
          : ''}
        <p class="mt-2 text-xs text-gray-500">${formatDate(review.createdAt)}${edited}</p>
      </div>`;
  }).join('');
}

// Открытие окна отзывов по кнопке "💬 Отзывы" на карточке
function openReviewsModal(productId) {
  const product = products.find((item) => item._id === productId);
  if (!product) return;

  reviewProductId = productId;
  currentReviews = [];
  document.getElementById('reviewsProductTitle').textContent = product.title;

  resetReviewForm();
  openModal('reviewsModal');
  loadReviews();
}

// Переход в режим редактирования: подставляем данные отзыва в форму
function startEditReview(reviewId) {
  const review = currentReviews.find((item) => String(item.id) === reviewId);
  if (!review) return;

  const form = document.getElementById('reviewForm');
  editingReviewId = reviewId;
  setStarRating(review.rating);
  document.getElementById('reviewComment').value = review.comment || '';
  form.querySelector('button[type="submit"]').textContent = 'Сохранить изменения';
  cancelEditBtn.classList.remove('hidden');

  updateReviewFormVisibility();
  form.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Удаление отзыва
async function deleteReview(reviewId) {
  const confirmedDelete = await confirmDialog({
    title: 'Удаление отзыва',
    message: 'Удалить этот отзыв? Это действие нельзя отменить.',
    confirmText: 'Удалить',
    danger: true
  });
  if (!confirmedDelete) return;

  try {
    const data = await apiRequest(`/products/reviews/${reviewId}`, { method: 'DELETE' });
    showToast(data.message, 'success');

    // Если удалили отзыв, который сейчас редактируется, — сбрасываем форму
    if (editingReviewId === reviewId) resetReviewForm();

    loadReviews();
    loadRatings();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Отправка формы: создание нового отзыва или сохранение изменений
async function submitReview(event) {
  event.preventDefault();
  const form = event.currentTarget;

  const comment = document.getElementById('reviewComment').value.trim();

  if (selectedRating < 1) {
    return showToast('Поставьте оценку от 1 до 5 звёзд', 'warning');
  }
  if (comment.length > 500) {
    return showToast('Комментарий не должен превышать 500 символов', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest(
      editingReviewId
        ? `/products/reviews/${editingReviewId}`
        : `/products/${reviewProductId}/review`,
      {
        method: editingReviewId ? 'PUT' : 'POST',
        body: { rating: selectedRating, comment }
      }
    );

    showToast(data.message, 'success');
    resetReviewForm();

    // Обновляем список отзывов в окне и рейтинги на карточках
    loadReviews();
    loadRatings();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
}

// Клик по звезде в форме
document.querySelectorAll('#starRating .star').forEach((star) => {
  star.addEventListener('click', () => setStarRating(Number(star.dataset.star)));
});

document.getElementById('reviewForm').addEventListener('submit', submitReview);

// Отмена редактирования
cancelEditBtn.addEventListener('click', () => {
  resetReviewForm();
  updateReviewFormVisibility();
});

// Кнопки ✎ и ✕ в списке отзывов (делегирование)
document.getElementById('reviewsList').addEventListener('click', (event) => {
  const editButton = event.target.closest('[data-review-edit]');
  if (editButton) {
    return startEditReview(editButton.dataset.reviewEdit);
  }

  const deleteButton = event.target.closest('[data-review-delete]');
  if (deleteButton) {
    deleteReview(deleteButton.dataset.reviewDelete);
  }
});

// Кнопка "💬 Отзывы" на карточках
cardActions.reviews = openReviewsModal;
