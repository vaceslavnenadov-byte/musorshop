// core.js
// Ядро: адрес API, общее состояние приложения, запросы к серверу, вспомогательные функции

// ==================== НАСТРОЙКИ ====================

// Адрес нашего бэкенда
// Сайт и API находятся на одном адресе, поэтому путь относительный
const API_URL = '/api';

// ==================== СОСТОЯНИЕ ПРИЛОЖЕНИЯ ====================

let products = [];           // все товары, загруженные с сервера
let currentUser = null;      // текущий пользователь (null = гость)
let wishlistIds = new Set(); // id товаров в избранном (заполним на шаге 21)
let ratings = {};            // рейтинги товаров (заполним на шаге 22)

// Обработчики кнопок на карточках: { buy: функция, reviews: функция, ... }
// На следующих шагах мы будем добавлять сюда новые действия
const cardActions = {};

// ==================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ====================

// Токен хранится в httpOnly-cookie и из JavaScript недоступен.
// В localStorage лежит только отметка "на этом устройстве входили в аккаунт":
// по ней страница понимает, стоит ли при загрузке запрашивать профиль
const SESSION_FLAG = 'loggedIn';

function hasSession() {
  try {
    return localStorage.getItem(SESSION_FLAG) === '1';
  } catch (err) {
    return false;
  }
}

function markSession(active) {
  try {
    if (active) {
      localStorage.setItem(SESSION_FLAG, '1');
    } else {
      localStorage.removeItem(SESSION_FLAG);
    }
    localStorage.removeItem('token'); // убираем токен, оставшийся от прежней схемы
  } catch (err) {
    // хранилище недоступно — сессия не восстановится после перезагрузки страницы
  }
}

// Сброс сессии (при выходе или если токен истёк)
function clearSession() {
  markSession(false);
  currentUser = null;
  wishlistIds = new Set();
}

// Экранирование спецсимволов HTML — защита от XSS.
// Всё, что пришло от пользователей (названия, описания, отзывы),
// перед вставкой в страницу пропускаем через эту функцию
function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Формат суммы: 100000 -> "100 000"
function formatPrice(value) {
  return Number(value || 0).toLocaleString('ru-RU');
}

// Универсальный запрос к API.
// Превращает тело в JSON и выбрасывает ошибку с текстом от сервера.
// Cookie с токеном браузер прикладывает сам
async function apiRequest(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    // Служебный заголовок: по нему сервер отличает запросы нашего сайта от поддельных (CSRF)
    'X-Requested-With': 'fetch'
  };
  const hadSession = hasSession();

  let response;
  try {
    response = await fetch(API_URL + path, {
      method: options.method || 'GET',
      headers,
      credentials: 'same-origin',
      body: options.body ? JSON.stringify(options.body) : undefined
    });
  } catch (err) {
    // fetch падает, только если сервер вообще не ответил
    throw new Error('Сервер недоступен. Проверьте, что бэкенд запущен');
  }

  let data = null;
  try {
    data = await response.json();
  } catch (err) {
    // ответ без JSON — оставляем data = null
  }

  // 401 при активной сессии = токен истёк, отозван или аккаунт заблокирован. Выходим из аккаунта
  if (response.status === 401 && hadSession) {
    clearSession();
    updateUI();
    renderProducts();
    renderRoute(); // если были в кабинете — возвращаемся в каталог
  }

  if (!response.ok) {
    throw new Error((data && data.message) || 'Ошибка запроса');
  }
  return data;
}
