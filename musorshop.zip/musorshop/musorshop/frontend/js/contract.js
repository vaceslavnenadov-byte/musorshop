// contract.js
// Контракт обмена: 10 предметов одной редкости обмениваются на 1 случайный предмет редкостью выше

// ==================== СОСТОЯНИЕ ====================

const CONTRACT_SIZE = 10;      // сколько предметов нужно для контракта
let contractInventory = [];    // предметы инвентаря, пригодные для обмена
let contractSelected = [];     // id выбранных предметов (по порядку добавления)
let contractOutcomes = null;   // возможные результаты (приходят с сервера, когда выбрано 10)
let contractBusy = false;      // идёт ли сейчас запрос на обмен

// Порядок редкостей от низшей к высшей
const RARITY_ORDER = ['milspec', 'restricted', 'classified', 'covert', 'gold'];

// ==================== ОТКРЫТИЕ ОКНА ====================

async function openContractModal() {
  contractSelected = [];
  contractOutcomes = null;
  document.getElementById('contractResult').classList.add('hidden');
  document.getElementById('contractInventory').innerHTML =
    '<p class="col-span-full text-sm text-gray-500">Загрузка…</p>';
  renderContract();
  openModal('contractModal');

  try {
    contractInventory = await apiRequest('/contract/inventory');
  } catch (err) {
    contractInventory = [];
    showToast(err.message, 'error');
  }
  renderContract();
}

// ==================== ОТРИСОВКА ====================

// Редкость, на которой "заперт" контракт (редкость первого выбранного предмета)
function getContractRarity() {
  if (contractSelected.length === 0) return null;
  const first = contractInventory.find((item) => item.id === contractSelected[0]);
  return first ? first.rarity : null;
}

// Маленькая плитка предмета (для ячеек контракта и списка инвентаря)
function createContractTile(item, { dimmed = false, action }) {
  const rarity = getRarity(item);
  const image = item.imageUrl
    ? `<img src="${escapeHtml(item.imageUrl)}" alt="" class="h-10 w-full object-contain" onerror="this.remove()">`
    : '<i class="fa-solid fa-image text-xl text-gray-600"></i>';

  return `
    <button type="button" ${action}="${escapeHtml(item.id)}" ${dimmed ? 'disabled' : ''}
            title="${escapeHtml(item.title)}"
            class="h-24 rounded-lg bg-gray-800 border-b-4 p-1 flex flex-col items-center justify-center gap-1 transition
                   ${dimmed ? 'opacity-30 cursor-not-allowed' : 'hover:bg-gray-700'}"
            style="border-color:${rarity.color}">
      ${image}
      <span class="w-full text-center text-[10px] leading-tight text-gray-300 truncate">${escapeHtml(item.title)}</span>
      <span class="text-[10px] text-gray-500">${formatPrice(item.price)} ₽</span>
    </button>`;
}

function renderContract() {
  const lockedRarity = getContractRarity();
  const selectedItems = contractSelected
    .map((id) => contractInventory.find((item) => item.id === id))
    .filter(Boolean);

  // ---------- Ячейки контракта: выбранные предметы и пустые места ----------
  let slots = selectedItems.map((item) => createContractTile(item, { action: 'data-contract-remove' })).join('');
  for (let i = selectedItems.length; i < CONTRACT_SIZE; i++) {
    slots += '<div class="h-24 rounded-lg border-2 border-dashed border-gray-700"></div>';
  }
  document.getElementById('contractSlots').innerHTML = slots;

  // ---------- Сводка ----------
  const total = selectedItems.reduce((sum, item) => sum + item.price, 0);
  const summary = document.getElementById('contractSummary');
  if (selectedItems.length === 0) {
    summary.textContent = 'Выберите 10 предметов одной редкости из инвентаря ниже';
  } else {
    const nextKey = RARITY_ORDER[RARITY_ORDER.indexOf(lockedRarity) + 1];
    summary.textContent =
      `Выбрано: ${selectedItems.length} из ${CONTRACT_SIZE} · ${getRarity({ rarity: lockedRarity }).label} → ` +
      `${getRarity({ rarity: nextKey }).label} · Стоимость: ${formatPrice(total)} ₽`;
  }

  // ---------- Инвентарь: ещё не выбранные предметы ----------
  const available = contractInventory.filter((item) => !contractSelected.includes(item.id));
  const full = contractSelected.length >= CONTRACT_SIZE;

  document.getElementById('contractInventory').innerHTML = available.length > 0
    ? available.map((item) => createContractTile(item, {
        action: 'data-contract-add',
        // Недоступны: предметы другой редкости, высшая редкость, предметы без редкости, заполненный контракт
        dimmed: full || !item.rarity || item.rarity === 'gold' || (lockedRarity && item.rarity !== lockedRarity)
      })).join('')
    : '<p class="col-span-full text-sm text-gray-500">В инвентаре нет подходящих предметов</p>';

  // ---------- Возможные результаты ----------
  const outcomes = document.getElementById('contractOutcomes');
  if (!full) {
    outcomes.innerHTML = '<p class="text-sm text-gray-500">Возможные результаты появятся, когда будут выбраны все 10 предметов</p>';
  } else if (contractOutcomes === null) {
    outcomes.innerHTML = '<p class="text-sm text-gray-500">Загрузка…</p>';
  } else {
    outcomes.innerHTML = contractOutcomes.map((item) => {
      const rarity = getRarity(item);
      return `
        <div class="flex items-center gap-3 bg-gray-800 rounded-lg p-2 border-l-4" style="border-color:${rarity.color}">
          <div class="flex-1 min-w-0">
            <p class="text-sm font-medium truncate">${escapeHtml(item.title)}</p>
            <p class="text-xs text-gray-400">${formatPrice(item.price)} ₽</p>
          </div>
          <span class="shrink-0 text-sm font-semibold">${formatChance(item.chance)}</span>
        </div>`;
    }).join('');
  }

  // ---------- Кнопка обмена ----------
  const button = document.getElementById('contractSubmitBtn');
  const ready = full && Array.isArray(contractOutcomes) && contractOutcomes.length > 0 && !contractBusy;
  button.disabled = !ready;
  button.classList.toggle('opacity-50', !ready);
  button.classList.toggle('cursor-not-allowed', !ready);
}

// Запрос возможных результатов для выбранных 10 предметов
async function loadContractPreview() {
  contractOutcomes = null;
  renderContract();

  // Запоминаем, для какого набора запрашиваем: пока идёт запрос, выбор мог измениться
  const requestedFor = contractSelected.join(',');

  try {
    const data = await apiRequest('/contract/preview', {
      method: 'POST',
      body: { purchaseIds: contractSelected }
    });
    if (requestedFor !== contractSelected.join(',')) return;
    contractOutcomes = data.outcomes;
  } catch (err) {
    if (requestedFor !== contractSelected.join(',')) return;
    contractOutcomes = [];
    showToast(err.message, 'warning', 6000);
  }
  renderContract();
}

// ==================== ВЫБОР ПРЕДМЕТОВ ====================

document.getElementById('contractInventory').addEventListener('click', (event) => {
  const button = event.target.closest('[data-contract-add]');
  if (!button || button.disabled || contractBusy) return;
  if (contractSelected.length >= CONTRACT_SIZE) return;

  contractSelected.push(button.dataset.contractAdd);
  document.getElementById('contractResult').classList.add('hidden');

  if (contractSelected.length === CONTRACT_SIZE) {
    loadContractPreview();
  } else {
    renderContract();
  }
});

// Клик по заполненной ячейке убирает предмет из контракта
document.getElementById('contractSlots').addEventListener('click', (event) => {
  const button = event.target.closest('[data-contract-remove]');
  if (!button || contractBusy) return;

  contractSelected = contractSelected.filter((id) => id !== button.dataset.contractRemove);
  contractOutcomes = null;
  renderContract();
});

// ==================== ОБМЕН ====================

document.getElementById('contractSubmitBtn').addEventListener('click', async () => {
  if (contractBusy || contractSelected.length !== CONTRACT_SIZE) return;

  const confirmed = await confirmDialog({
    title: 'Контракт обмена',
    message: 'Обменять 10 выбранных предметов на один случайный предмет редкостью выше? Отменить обмен будет нельзя.',
    confirmText: 'Обменять'
  });
  if (!confirmed) return;

  contractBusy = true;
  renderContract();

  try {
    const data = await apiRequest('/contract', {
      method: 'POST',
      body: { purchaseIds: contractSelected }
    });

    const rarity = getRarity(data.item);
    const result = document.getElementById('contractResult');
    result.innerHTML = `
      <p class="text-sm text-gray-400">Вы получили</p>
      <p class="mt-1 text-xl font-bold" style="color:${rarity.color}">${escapeHtml(data.item.title)}</p>
      <p class="text-sm text-gray-300">${rarity.label} · стоимость ${formatPrice(data.item.price)} ₽</p>`;
    result.classList.remove('hidden');

    playSuccessSound();
    showToast(`Контракт выполнен: ${data.item.title}`, 'success', 5000);

    // Обмененные предметы исчезли, новый появился — обновляем окно и кабинет
    contractSelected = [];
    contractOutcomes = null;
    contractInventory = await apiRequest('/contract/inventory');
    loadPurchases();
  } catch (err) {
    showToast(err.message, 'error', 6000);
  } finally {
    contractBusy = false;
    renderContract();
  }
});

// Кнопка в личном кабинете
document.getElementById('contractBtn').addEventListener('click', openContractModal);
