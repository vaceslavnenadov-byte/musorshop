// info.js
// Футер: информационные разделы на двух языках

// ==================== ФУТЕР: ИНФОРМАЦИОННЫЕ РАЗДЕЛЫ ====================

// Контакт для раздела "Связаться с нами" — ЗАМЕНИ на свой адрес
const CONTACT_EMAIL = 'vaceslavnenadov@gmail.com';

// Тексты разделов. Это наш собственный статичный HTML (не данные пользователей),
// поэтому его можно вставлять в страницу как есть
const INFO_PAGES = {
  help: {
    title: 'Центр помощи',
    html: `
      <p><b>Как купить скин.</b> Зарегистрируйтесь, войдите в аккаунт и нажмите «Купить» на карточке товара.
         Несколько товаров удобнее сложить в корзину и оплатить одним действием.</p>
      <p><b>Как пополнить баланс.</b> Личный кабинет → «Пополнить». Там же вводится промокод.</p>
      <p><b>Как продать скин.</b> Личный кабинет → «Инвентарь и покупки» → «Продать». Вы получите 80% от стоимости предмета.</p>
      <p><b>Как открыть кейс.</b> Раздел «Кейсы» → выберите кейс → «Открыть». Шансы выпадения указаны в списке содержимого.</p>`
  },
  faq: {
    title: 'Частые вопросы',
    html: `
      <p><b>Это настоящие деньги?</b><br>Нет. MusorShop — учебный проект, баланс и предметы виртуальные.</p>
      <p><b>Почему при продаже возвращается только 80%?</b><br>20% — комиссия магазина за обратный выкуп предмета.</p>
      <p><b>Можно ли использовать промокод дважды?</b><br>Нет, каждый промокод активируется один раз на аккаунт.</p>
      <p><b>Как считаются шансы в кейсах?</b><br>Шанс зависит от редкости предмета. Результат определяет сервер
         в момент открытия, анимация только показывает его.</p>
      <p><b>Меня выбросило из аккаунта. Почему?</b><br>Сессия действует сутки. Она также завершается после смены пароля
         на другом устройстве.</p>`
  },
  contact: {
    title: 'Связаться с нами',
    html: `
      <p>По вопросам работы сайта напишите автору проекта:</p>
      <p><a href="mailto:${CONTACT_EMAIL}" class="text-yellow-500 hover:underline">${CONTACT_EMAIL}</a></p>
      <p>В письме укажите email вашего аккаунта и опишите, что произошло.</p>`
  },
  partners: {
    title: 'Партнёрская программа',
    html: `
      <p>MusorShop — учебный проект, поэтому действующей партнёрской программы у него нет.</p>
      <p>В реальном магазине здесь были бы условия: процент с покупок приглашённых пользователей и личная ссылка партнёра.
         Ближайший аналог на сайте — промокоды, которые администратор создаёт в своей панели.</p>`
  },
  ads: {
    title: 'Реклама',
    html: `
      <p>Рекламные места на сайте не продаются: проект некоммерческий и создан в учебных целях.</p>`
  },
  streamers: {
    title: 'Для стримеров',
    html: `
      <p>Отдельной программы для стримеров нет. Администратор может выпустить именной промокод
         с ограниченным числом активаций, которым стример поделится со зрителями.</p>`
  },
  terms: {
    title: 'Пользовательское соглашение',
    html: `
      <p><b>1. О проекте.</b> MusorShop — учебный проект. Сайт не является магазином
         и не связан с Valve или Steam.</p>
      <p><b>2. Виртуальные средства.</b> Баланс, предметы, кейсы и промокоды не имеют денежной стоимости,
         не покупаются за настоящие деньги и не подлежат выводу или обмену.</p>
      <p><b>3. Аккаунт.</b> Один человек использует один аккаунт. Пользователь сам отвечает за сохранность пароля.</p>
      <p><b>4. Отзывы.</b> Запрещены оскорбления и реклама. Администратор может изменить или удалить отзыв;
         изменённые отзывы помечаются.</p>
      <p><b>5. Блокировка.</b> За нарушение правил администратор может заблокировать аккаунт.</p>`
  },
  privacy: {
    title: 'Политика конфиденциальности',
    html: `
      <p><b>Какие данные хранятся.</b> Email, пароль в виде необратимого хеша (bcrypt), баланс,
         история покупок и операций, отзывы и список избранного.</p>
      <p><b>Чего мы не делаем.</b> Пароль в открытом виде не хранится и не может быть восстановлен.
         Данные не передаются третьим лицам.</p>
      <p><b>Что видно другим.</b> В отзывах email показывается в скрытом виде, например bu***@mail.ru.</p>
      <p><b>Что хранится в браузере.</b> Токен входа, содержимое корзины и настройки отображения каталога.
         Они удаляются при очистке данных сайта в браузере.</p>`
  },
  social: {
    title: 'Мы в соцсетях',
    html: `
      <p>У учебного проекта нет страниц в социальных сетях. Значки показывают, как этот блок выглядел бы
         на настоящем сайте.</p>`
  }
};

// Клик по любой кнопке с атрибутом data-info открывает окно с нужным разделом
document.addEventListener('click', (event) => {
  const button = event.target.closest('[data-info]');
  if (!button) return;

  // Тексты разделов хранятся целиком на двух языках
  const pages = i18n.getLanguage() === 'en' ? INFO_PAGES_EN : INFO_PAGES;
  const page = pages[button.dataset.info];
  if (!page) return;

  document.getElementById('infoTitle').textContent = page.title;
  document.getElementById('infoContent').innerHTML = page.html;
  openModal('infoModal');
});

// ==================== ПЕРЕВОД: АНГЛИЙСКИЕ ТЕКСТЫ РАЗДЕЛОВ ФУТЕРА ====================

const INFO_PAGES_EN = {
  help: {
    title: 'Help center',
    html: `
      <p><b>How to buy a skin.</b> Sign up, log in and press Buy on an item card.
         To buy several items at once, add them to the cart and check out.</p>
      <p><b>How to top up the balance.</b> My account → Top up. Promo codes are entered there too.</p>
      <p><b>How to sell a skin.</b> My account → Inventory and purchases → Sell. You receive 80% of the item value.</p>
      <p><b>How to open a case.</b> Cases → choose a case → Open. Drop chances are listed in the case contents.</p>`
  },
  faq: {
    title: 'FAQ',
    html: `
      <p><b>Is this real money?</b><br>No. MusorShop is a student project; the balance and items are virtual.</p>
      <p><b>Why do I get only 80% back when selling?</b><br>20% is the shop commission for buying the item back.</p>
      <p><b>Can I use a promo code twice?</b><br>No, each promo code can be redeemed once per account.</p>
      <p><b>How are case chances calculated?</b><br>The chance depends on the item rarity. The server decides the result
         at the moment of opening; the animation only shows it.</p>
      <p><b>I was logged out. Why?</b><br>A session lasts one day. It also ends after the password is changed
         on another device.</p>`
  },
  contact: {
    title: 'Contact us',
    html: `
      <p>For questions about the site, write to the project author:</p>
      <p><a href="mailto:${CONTACT_EMAIL}" class="text-yellow-500 hover:underline">${CONTACT_EMAIL}</a></p>
      <p>Please include the email of your account and describe what happened.</p>`
  },
  partners: {
    title: 'Affiliate program',
    html: `
      <p>MusorShop is a student project, so it has no active affiliate program.</p>
      <p>A real shop would list its terms here: a share of purchases made by invited users and a personal link.
         The closest equivalent on this site is promo codes, which the administrator creates in the admin panel.</p>`
  },
  ads: {
    title: 'Advertising',
    html: `
      <p>Advertising space is not sold: the project is non-commercial and was created for educational purposes.</p>`
  },
  streamers: {
    title: 'For streamers',
    html: `
      <p>There is no separate program for streamers. The administrator can issue a personal promo code
         with a limited number of activations for a streamer to share with viewers.</p>`
  },
  terms: {
    title: 'Terms of use',
    html: `
      <p><b>1. About the project.</b> MusorShop is a student coursework project. The site is not a shop
         and is not affiliated with Valve or Steam.</p>
      <p><b>2. Virtual funds.</b> The balance, items, cases and promo codes have no monetary value,
         cannot be bought with real money and cannot be withdrawn or exchanged.</p>
      <p><b>3. Account.</b> One person uses one account. Users are responsible for keeping their password safe.</p>
      <p><b>4. Reviews.</b> Insults and advertising are not allowed. The administrator may edit or delete a review;
         edited reviews are marked.</p>
      <p><b>5. Blocking.</b> The administrator may block an account for breaking the rules.</p>`
  },
  privacy: {
    title: 'Privacy policy',
    html: `
      <p><b>What is stored.</b> Email, the password as an irreversible hash (bcrypt), balance,
         purchase and transaction history, reviews and the wishlist.</p>
      <p><b>What we do not do.</b> The password is never stored in plain text and cannot be recovered.
         Data is not shared with third parties.</p>
      <p><b>What others can see.</b> In reviews the email is shown masked, for example bu***@mail.com.</p>
      <p><b>What is kept in the browser.</b> The login token, cart contents and catalog display settings.
         They are removed when you clear the site data in your browser.</p>`
  },
  social: {
    title: 'Social media',
    html: `
      <p>This student project has no social media pages. The icons show what this block would look like
         on a real site.</p>`
  }
};

// Содержимое информационного окна уже приходит на нужном языке —
// просим слой перевода его не трогать
document.getElementById('infoContent').setAttribute('data-no-i18n', '');

// При смене языка перерисовываем график: его подписи рисуются на холсте, а не в HTML
window.addEventListener('i18n:change', () => {
  if (salesChart) renderSalesChart();
});
