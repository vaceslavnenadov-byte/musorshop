// ==================== СЛОЙ ПЕРЕВОДА ИНТЕРФЕЙСА (RU → EN) ====================
// Русский текст в разметке и коде остаётся исходным. Когда выбран английский язык,
// этот скрипт находит русские тексты на странице и заменяет их по словарю.
// За изменениями страницы следит MutationObserver, поэтому переводится и то,
// что появляется позже: списки, уведомления, окна.

(function () {
  // ---------- Словарь точных соответствий ----------
  const DICT = {
    // Журнал действий администратора
    '🛡 Действия': '🛡 Actions',
    'Действия администраторов:': 'Administrator actions:',
    'Раздел': 'Section',
    'Все действия': 'All actions',
    'Товары': 'Items',
    'Пользователи': 'Users',
    'Действий пока нет': 'No actions yet',
    'Не удалось загрузить журнал действий': 'Failed to load the action log',
    'Создан товар': 'Item created',
    'Изменён товар': 'Item updated',
    'Удалён товар': 'Item deleted',
    'Создан промокод': 'Promo code created',
    'Изменён промокод': 'Promo code updated',
    'Удалён промокод': 'Promo code deleted',
    'Создан кейс': 'Case created',
    'Изменён кейс': 'Case updated',
    'Удалён кейс': 'Case deleted',
    'Заблокирован пользователь': 'User blocked',
    'Разблокирован пользователь': 'User unblocked',
    'Изменён баланс': 'Balance changed',
    'Изменён отзыв': 'Review edited',
    'Удалён отзыв': 'Review deleted',
    'Снят лот': 'Lot removed',
    'Показать подробности': 'Show details',
    'Что изменилось': 'What changed',
    'Поле': 'Field',
    'Было': 'Before',
    'Стало': 'After',
    'Данные на момент действия': 'Data at the time of the action',
    'Форма была сохранена без изменений: значения полей остались прежними': 'The form was saved without changes: field values stayed the same',
    'Для этого действия дополнительных сведений нет: всё указано в заголовке': 'There are no additional details for this action: everything is in the heading',
    'Цена': 'Price',
    'Картинка': 'Image',
    'Тип': 'Type',
    'Активаций': 'Activations',
    'Предметов в кейсе': 'Items in the case',
    'Оценка': 'Rating',
    'Комментарий': 'Comment',
    'Цена лота': 'Lot price',
    'Стоимость предмета': 'Item value',
    'Да': 'Yes',
    'Нет': 'No',
    'Фиксированная сумма': 'Fixed amount',
    'Процент к пополнению': 'Percentage on top-up',
    // Уведомления
    'Уведомления': 'Notifications',
    'Уведомлений пока нет': 'No notifications yet',
    'Уведомления прочитаны': 'Notifications marked as read',
    'Уведомления удалены': 'Notifications deleted',
    // Лента событий
    'Последние события': 'Recent events',
    'Событий пока нет: первая покупка появится здесь': 'No events yet: the first purchase will appear here',
    'Покупка в магазине': 'Shop purchase',
    'Выпало из кейса': 'Dropped from a case',
    'Слишком много подключений. Попробуйте позже': 'Too many connections. Try again later',
    // Уровень и ежедневный бонус
    'Уровень': 'Level',
    'Ежедневный бонус': 'Daily bonus',
    '🎁 Забрать бонус': '🎁 Claim bonus',
    'Забрать ежедневный бонус': 'Claim the daily bonus',
    'Ежедневные бонусы': 'Daily bonuses',
    'Сегодняшний бонус уже получен': 'Today\u2019s bonus has already been claimed',
    'Администратору бонус не положен': 'Administrators are not eligible for the bonus',
    // Контракт обмена
    'Контракт обмена': 'Trade-up contract',
    'Отдайте 10 предметов одной редкости и получите 1 случайный предмет редкостью выше.':
      'Give 10 items of the same rarity and receive 1 random item of the next rarity.',
    'Обменять': 'Trade up',
    'Инвентарь': 'Inventory',
    'Возможные результаты': 'Possible outcomes',
    'Выберите 10 предметов одной редкости из инвентаря ниже': 'Select 10 items of the same rarity from the inventory below',
    'В инвентаре нет подходящих предметов': 'No suitable items in the inventory',
    'Возможные результаты появятся, когда будут выбраны все 10 предметов': 'Possible outcomes will appear once all 10 items are selected',
    'Обменять 10 выбранных предметов на один случайный предмет редкостью выше? Отменить обмен будет нельзя.':
      'Trade the 10 selected items for one random item of the next rarity? This cannot be undone.',
    'Вы получили': 'You received',
    'по контракту': 'from a contract',
    'ОБМЕНЯН ПО КОНТРАКТУ': 'TRADED UP',
    'Обменян по контракту': 'Traded up',
    'Контракт выполнен': 'Contract completed',
    'Администратор не может заключать контракты': 'Administrators cannot make contracts',
    'Некоторые предметы не найдены в инвентаре или уже недоступны': 'Some items were not found in the inventory or are no longer available',
    'Среди выбранных есть предмет, которого больше нет в магазине: его редкость неизвестна': 'One of the selected items is no longer in the shop: its rarity is unknown',
    'Все предметы контракта должны быть одной редкости': 'All contract items must be of the same rarity',
    'Предметы высшей редкости обменять нельзя': 'Items of the highest rarity cannot be traded up',
    'Для этого набора нет подходящего результата: суммарная стоимость предметов слишком мала. Выберите предметы подороже':
      'There is no suitable outcome for this set: the total value of the items is too low. Choose more valuable items',
    'Некоторые предметы уже недоступны. Обновите список и попробуйте снова': 'Some items are no longer available. Refresh the list and try again',
    // Шапка, главная, футер
    'Меню': 'Menu',
    'Главная': 'Home',
    'Кейсы': 'Cases',
    'Регистрация': 'Sign up',
    'Авторизация': 'Log in',
    'Личный кабинет': 'My account',
    'Выйти': 'Log out',
    'Корзина': 'Cart',
    'Тема оформления': 'Theme',
    'Системная': 'System',
    'Светлая': 'Light',
    'Тёмная': 'Dark',
    'Тема: системная': 'Theme: system',
    'Тема: светлая': 'Theme: light',
    'Тема: тёмная': 'Theme: dark',
    'Добро пожаловать в Musor': 'Welcome to Musor',
    'Маркетплейс скинов CS2. Покупайте предметы и продавайте их обратно за 80% цены в любой момент.':
      'A CS2 skin marketplace. Buy items and sell them back for 80% of the price at any time.',
    'Поиск по названию или описанию': 'Search by title or description',
    'Сначала новые': 'Newest first',
    'Цена: по возрастанию': 'Price: low to high',
    'Цена: по убыванию': 'Price: high to low',
    'Название: А–Я': 'Title: A–Z',
    'Название: Я–А': 'Title: Z–A',
    'По остатку': 'By stock',
    'Загрузка товаров…': 'Loading items…',
    'Ничего не найдено': 'Nothing found',
    'Попробуйте изменить запрос': 'Try a different search',
    'Маркетплейс игровых предметов CS2. Учебный проект.': 'A marketplace for CS2 items. A student project.',
    'Центр помощи': 'Help center',
    'Частые вопросы': 'FAQ',
    'Связаться с нами': 'Contact us',
    'Партнёрская программа': 'Affiliate program',
    'Реклама': 'Advertising',
    'Для стримеров': 'For streamers',
    'Пользовательское соглашение': 'Terms of use',
    'Политика конфиденциальности': 'Privacy policy',
    'О нас': 'About us',
    'MusorShop — учебный проект (курсовая работа). Маркетплейс скинов CS2 на Node.js, Express и MongoDB. Все деньги и предметы здесь виртуальные.':
      'MusorShop is a student coursework project: a CS2 skin marketplace built with Node.js, Express and MongoDB. All money and items here are virtual.',
    '© 2026 MusorShop. Проект не связан с Valve.': '© 2026 MusorShop. Not affiliated with Valve.',
    'Язык': 'Language',
    'Наверх': 'Back to top',
    'Закрыть': 'Close',
    'MusorShop — маркетплейс скинов CS2': 'MusorShop — CS2 skin marketplace',
    'Кейсы — MusorShop': 'Cases — MusorShop',
    'Личный кабинет — MusorShop': 'My account — MusorShop',

    // Карточки товаров и редкость
    'Все категории': 'All categories',
    'Любая редкость': 'Any rarity',
    'Любое качество': 'Any wear',
    'Цена от, ₽': 'Price from, ₽',
    'Цена до, ₽': 'Price to, ₽',
    'Только в наличии': 'In stock only',
    'Только StatTrak™': 'StatTrak™ only',
    'Только избранное': 'Wishlist only',
    'Сбросить фильтры': 'Reset filters',
    'Найдено:': 'Found:',
    'Нет оценок': 'No ratings',
    'Нет в наличии': 'Out of stock',
    'нет в наличии': 'out of stock',
    '💬 Отзывы': '💬 Reviews',
    'Купить': 'Buy',
    'Добавить товар': 'Add item',
    'Редактировать': 'Edit',
    'Удалить': 'Delete',
    'Изменить': 'Edit',
    'Добавить в избранное': 'Add to wishlist',
    'Убрать из избранного': 'Remove from wishlist',
    'Добавить в корзину': 'Add to cart',
    'Уже в корзине — добавить ещё': 'Already in cart — add one more',
    'Товаров пока нет': 'No items yet',
    'Не удалось загрузить товары': 'Failed to load items',
    '← Назад': '← Back',
    'Вперёд →': 'Next →',
    'Армейское': 'Mil-Spec',
    'Запрещённое': 'Restricted',
    'Засекреченное': 'Classified',
    'Тайное': 'Covert',
    'Редкое': 'Rare',
    'Редкое (золото)': 'Rare (gold)',

    // Вход, регистрация, пароль
    'Код с картинки': 'Code from the image',
    'Проверочный код': 'Verification code',
    'Другой код': 'Another code',
    'Показать другой код': 'Show another code',
    'Символы': 'Characters',
    'Введите код с картинки': 'Enter the code from the image',
    'Код с картинки введён неверно. Попробуйте ещё раз': 'The code from the image is incorrect. Try again',
    'Не удалось загрузить проверочный код': 'Failed to load the verification code',
    'Пароль': 'Password',
    'Ваш пароль': 'Your password',
    'Войти': 'Log in',
    'Нет аккаунта?': 'No account?',
    'Зарегистрироваться': 'Sign up',
    'Стартовый баланс — 100 000 ₽': 'Starting balance: 100 000 ₽',
    'Пароль (от 5 символов)': 'Password (at least 5 characters)',
    'Придумайте пароль': 'Create a password',
    'Подтверждение пароля': 'Confirm password',
    'Повторите пароль': 'Repeat the password',
    'Уже есть аккаунт?': 'Already have an account?',
    'Смена пароля': 'Change password',
    'Старый пароль': 'Current password',
    'Новый пароль (от 5 символов)': 'New password (at least 5 characters)',
    'Подтверждение нового пароля': 'Confirm new password',
    'Сохранить пароль': 'Save password',
    'Показать пароль': 'Show password',
    'Скрыть пароль': 'Hide password',
    'Слабый пароль': 'Weak password',
    'Средний пароль': 'Fair password',
    'Хороший пароль': 'Good password',
    'Надёжный пароль': 'Strong password',
    'Введите корректный email (например, name@mail.ru)': 'Enter a valid email (for example, name@mail.com)',
    'Пароли не совпадают': 'Passwords do not match',
    'Регистрация прошла успешно. Теперь войдите в аккаунт': 'Registration successful. Now log in',
    'Регистрация прошла успешно': 'Registration successful',
    'Введите email и пароль': 'Enter email and password',
    'Вы вышли из аккаунта': 'You have logged out',
    'Заполните все поля': 'Fill in all fields',
    'Новые пароли не совпадают': 'New passwords do not match',
    'Некорректный email': 'Invalid email',
    'Пользователь с таким email уже существует': 'A user with this email already exists',
    'Неверный email или пароль': 'Wrong email or password',
    'Новый пароль совпадает со старым': 'The new password is the same as the current one',
    'Старый пароль введён неверно': 'The current password is incorrect',
    'Пароль успешно изменён': 'Password changed',

    // Общие ошибки и сервер
    'Ошибка сервера': 'Server error',
    'Ошибка запроса': 'Request failed',
    'Пользователь не найден': 'User not found',
    'Требуется авторизация': 'Authorization required',
    'Недействительный или просроченный токен': 'Invalid or expired token',
    'Сессия завершена. Войдите заново': 'Session ended. Please log in again',
    'Аккаунт заблокирован администратором': 'The account has been blocked by an administrator',
    'Доступ только для администратора': 'Administrators only',
    'Маршрут не найден': 'Route not found',
    'Некорректный JSON в запросе': 'Malformed JSON in the request',
    'Слишком большой запрос': 'Request too large',
    'Сервер недоступен. Проверьте, что бэкенд запущен': 'Server unavailable. Check that the backend is running',
    'Слишком много неудачных попыток входа. Попробуйте через 5 минут': 'Too many failed login attempts. Try again in 5 minutes',
    'Слишком много регистраций. Попробуйте позже': 'Too many registrations. Try again later',
    'Слишком много попыток ввода промокода. Попробуйте через 10 минут': 'Too many promo code attempts. Try again in 10 minutes',
    'Слишком много запросов. Подождите минуту': 'Too many requests. Wait a minute',
    'Эта функция появится на следующих шагах': 'This feature is coming soon',
    'Подтверждение': 'Confirmation',
    'Подтвердить': 'Confirm',
    'Отмена': 'Cancel',

    // Покупка и продажа
    'Войдите в аккаунт, чтобы покупать': 'Log in to buy',
    'Недостаточно средств на балансе': 'Insufficient balance',
    'Покупка': 'Purchase',
    'Продажа': 'Sale',
    'Продать': 'Sell',
    'Покупка не найдена или уже продана': 'Purchase not found or already sold',
    'Некорректный идентификатор покупки': 'Invalid purchase id',
    'Администратор не может покупать товары': 'Administrators cannot buy items',
    'Некорректный идентификатор товара': 'Invalid item id',
    'Товар закончился': 'Item is out of stock',
    'Товар не найден': 'Item not found',

    // Личный кабинет
    'В каталог': 'Back to catalog',
    'Роль': 'Role',
    'Покупатель': 'Buyer',
    'Администратор': 'Administrator',
    'Баланс': 'Balance',
    '🔒 Сменить пароль': '🔒 Change password',
    '💰 Пополнить': '💰 Top up',
    'Скопировать email': 'Copy email',
    'Email скопирован в буфер обмена': 'Email copied to clipboard',
    'Не удалось скопировать email': 'Failed to copy email',
    'Инвентарь и покупки': 'Inventory and purchases',
    'Предметов в инвентаре': 'Items in inventory',
    'Стоимость инвентаря': 'Inventory value',
    'Потрачено на покупки': 'Spent on purchases',
    'Получено с продаж': 'Earned from sales',
    'Все': 'All',
    'В инвентаре': 'In inventory',
    'Проданные': 'Sold',
    'Покупок пока нет': 'No purchases yet',
    'В инвентаре пусто': 'The inventory is empty',
    'Проданных предметов нет': 'No sold items',
    'Загрузка…': 'Loading…',
    'Не удалось загрузить покупки': 'Failed to load purchases',
    'ПРОДАНО': 'SOLD',
    'из кейса': 'from a case',
    'Избранное': 'Wishlist',
    'В избранном пока пусто': 'The wishlist is empty',
    'Не удалось загрузить избранное': 'Failed to load the wishlist',
    'Войдите в аккаунт, чтобы пользоваться избранным': 'Log in to use the wishlist',
    'Удалено из избранного': 'Removed from wishlist',
    'Добавлено в избранное': 'Added to wishlist',
    'История операций': 'Transaction history',
    'Показать ещё': 'Show more',
    'Операций пока нет': 'No transactions yet',
    'Не удалось загрузить операции': 'Failed to load transactions',
    'Пополнение': 'Top-up',
    'Промокод': 'Promo code',
    'Корректировка': 'Adjustment',
    'Кейс': 'Case',
    'Пополнение баланса': 'Balance top-up',

    // Пополнение и промокоды (покупатель)
    'Максимум за одно пополнение — 1 000 000 ₽': 'Maximum per top-up: 1 000 000 ₽',
    'Сумма, ₽': 'Amount, ₽',
    'Введите сумму': 'Enter an amount',
    'Пополнить': 'Top up',
    'Введите сумму целым положительным числом': 'Enter the amount as a positive whole number',
    'Введите корректную сумму': 'Enter a valid amount',
    'Баланс пополнен': 'Balance topped up',
    'Например, WELCOME': 'For example, WELCOME',
    'Применить': 'Apply',
    'Если промокод даёт процент к пополнению, сначала введите сумму в поле выше. Кнопка «Применить» пополнит баланс на эту сумму и добавит бонус.':
      'If the promo code gives a percentage bonus, enter the amount above first. The Apply button will top up the balance by that amount and add the bonus.',
    'Введите промокод': 'Enter a promo code',
    'Промокод не найден': 'Promo code not found',
    'Вы уже активировали этот промокод': 'You have already used this promo code',
    'Промокод больше не действует': 'This promo code is no longer valid',
    'Администратор не может активировать промокоды': 'Administrators cannot redeem promo codes',
    'Введите корректную сумму пополнения': 'Enter a valid top-up amount',

    // Форма товара и загрузка картинки
    'Категория': 'Category',
    'Качество': 'Wear',
    'Не указано': 'Not specified',
    'StatTrak™ (счётчик убийств)': 'StatTrak™ (kill counter)',
    'Винтовки': 'Rifles',
    'Снайперские винтовки': 'Sniper rifles',
    'Пистолеты': 'Pistols',
    'Пистолеты-пулемёты': 'SMGs',
    'Тяжёлое оружие': 'Heavy weapons',
    'Ножи': 'Knives',
    'Перчатки': 'Gloves',
    'Другое': 'Other',
    'Некорректная категория': 'Invalid category',
    'Некорректное качество': 'Invalid wear',
    'Некорректное значение StatTrak': 'Invalid StatTrak value',    
    'Редактировать товар': 'Edit item',
    'Название': 'Title',
    'Описание': 'Description',
    'Качество, редкость, особенности': 'Wear, rarity, details',
    'Цена, ₽': 'Price, ₽',
    'Количество': 'Quantity',
    'Редкость': 'Rarity',
    'Ссылка на картинку': 'Image URL',
    'Или загрузите файл (JPG, PNG, GIF, WebP, до 2 МБ)': 'Or upload a file (JPG, PNG, GIF, WebP, up to 2 MB)',
    'Предпросмотр картинки': 'Image preview',
    'Сохранить': 'Save',
    'Сохранить изменения': 'Save changes',
    'Добавить': 'Add',
    'Введите название товара': 'Enter the item title',
    'Цена должна быть неотрицательным числом': 'The price must be a non-negative number',
    'Количество должно быть целым неотрицательным числом': 'The quantity must be a non-negative whole number',
    'Ссылка на картинку должна начинаться с http:// или https://': 'The image URL must start with http:// or https://',
    'Товар обновлён': 'Item updated',
    'Товар добавлен': 'Item added',
    'Товар удалён': 'Item deleted',
    'Удаление товара': 'Delete item',
    'Допустимы только изображения JPG, PNG, GIF и WebP': 'Only JPG, PNG, GIF and WebP images are allowed',
    'Файл слишком большой. Максимум — 2 МБ': 'The file is too large. Maximum is 2 MB',
    'Картинка загружена. Не забудьте сохранить товар': 'Image uploaded. Remember to save the item',
    'Не удалось загрузить файл': 'Failed to upload the file',
    'Не удалось принять файл': 'Failed to receive the file',
    'Файл не выбран': 'No file selected',
    'Не удалось сохранить файл': 'Failed to save the file',
    'Некорректное описание': 'Invalid description',
    'Некорректная ссылка на картинку': 'Invalid image URL',
    'Некорректная редкость': 'Invalid rarity',

    // Панель администратора: статистика
    'Панель администратора': 'Admin panel',
    '📊 Статистика': '📊 Statistics',
    '🎟 Промокоды': '🎟 Promo codes',
    '📒 Журнал': '📒 Log',
    '👥 Пользователи': '👥 Users',
    'Чистая прибыль': 'Net profit',
    'Покупок': 'Purchases',
    'Пользователей': 'Users',
    'Товаров': 'Items',
    'Топ-5 покупателей': 'Top 5 buyers',
    'Топ-5 товаров': 'Top 5 items',
    'Заканчиваются': 'Running low',
    'Нет данных': 'No data',
    'Продажи за 30 дней': 'Sales in the last 30 days',
    'Оборот': 'Turnover',
    'Кол-во': 'Count',
    'Экспорт в CSV': 'Export to CSV',
    'Покупок пока нет — выгружать нечего': 'No purchases yet, nothing to export',
    'Библиотека Chart.js не загрузилась. Проверьте интернет': 'Chart.js failed to load. Check your connection',
    'Товар': 'Item',
    'Статус': 'Status',
    'Дата покупки': 'Purchase date',
    'Дата продажи': 'Sale date',
    'Продано': 'Sold',
    'Активно': 'Active',

    // Панель администратора: промокоды
    'Код': 'Code',
    'Процент, %': 'Percent, %',
    'Бонус, ₽': 'Bonus, ₽',
    'Лимит активаций': 'Activation limit',
    'Тип промокода': 'Promo code type',
    'Размер бонуса': 'Bonus size',
    'Создать': 'Create',
    'Промокодов пока нет': 'No promo codes yet',
    'Не удалось загрузить промокоды': 'Failed to load promo codes',
    'Изменить промокод': 'Edit promo code',
    'Удалить промокод': 'Delete promo code',
    'Код: от 3 до 20 символов, латинские буквы, цифры, дефис и подчёркивание': 'Code: 3 to 20 characters, Latin letters, digits, hyphen and underscore',
    'Лимит активаций должен быть целым числом от 1': 'The activation limit must be a whole number of at least 1',
    'Удаление промокода': 'Delete promo code',
    'Удалить этот промокод? Уже начисленные бонусы останутся у пользователей.': 'Delete this promo code? Bonuses already granted will stay with the users.',
    'Промокод создан': 'Promo code created',
    'Промокод обновлён': 'Promo code updated',
    'Промокод удалён': 'Promo code deleted',
    'Такой промокод уже существует': 'This promo code already exists',
    'Некорректный тип промокода': 'Invalid promo code type',
    'Размер бонуса должен быть целым положительным числом': 'The bonus must be a positive whole number',
    'Некорректный идентификатор промокода': 'Invalid promo code id',

    // Панель администратора: журнал и пользователи
    'Все операции пользователей': 'All user transactions',
    'Тип операции': 'Transaction type',
    'Все типы': 'All types',
    'Пополнения': 'Top-ups',
    'Покупки': 'Purchases',
    'Продажи': 'Sales',
    'Промокоды': 'Promo codes',
    'Корректировки': 'Adjustments',
    'Пользователи:': 'Users:',
    'Поиск по email': 'Search by email',
    'Никого не найдено': 'No one found',
    'Не удалось загрузить пользователей': 'Failed to load users',
    'админ': 'admin',
    'заблокирован': 'blocked',
    'Заблокировать': 'Block',
    'Разблокировать': 'Unblock',
    'Блокировка пользователя': 'Block user',
    'Разблокировка пользователя': 'Unblock user',
    'Пользователь заблокирован': 'User blocked',
    'Пользователь разблокирован': 'User unblocked',
    'Нельзя заблокировать администратора': 'An administrator cannot be blocked',
    'Не указано действие': 'No action specified',
    'Некорректный идентификатор пользователя': 'Invalid user id',
    'Корректировка баланса': 'Balance adjustment',
    'Например, 5000 или -5000': 'For example, 5000 or -5000',
    'Положительное число начисляет, отрицательное списывает': 'A positive number credits, a negative one debits',
    'Причина': 'Reason',
    'Например, компенсация за ошибку': 'For example, compensation for an error',
    'Сумма должна быть целым числом, не равным нулю': 'The amount must be a non-zero whole number',
    'Укажите причину корректировки': 'Enter the reason for the adjustment',
    'Нельзя списать больше, чем есть на балансе': 'Cannot debit more than the current balance',

    // Отзывы
    'Отзыв могут оставить только покупатели этого товара': 'Only buyers of this item can post a review',
    '✔ Проверенная покупка': '✔ Verified purchase',
    'Отзывы': 'Reviews',
    'из 5': 'out of 5',
    'Отзывов:': 'Reviews:',
    'Ваша оценка': 'Your rating',
    '1 звезда': '1 star',
    '2 звезды': '2 stars',
    '3 звезды': '3 stars',
    '4 звезды': '4 stars',
    '5 звёзд': '5 stars',
    'Комментарий (до 500 символов)': 'Comment (up to 500 characters)',
    'Поделитесь впечатлением': 'Share your impression',
    'Оставить отзыв': 'Post review',
    'Отзывов пока нет': 'No reviews yet',
    'Не удалось загрузить отзывы': 'Failed to load reviews',
    'изменено': 'edited',
    'изменено администратором': 'edited by an administrator',
    'Изменить отзыв': 'Edit review',
    'Удалить отзыв': 'Delete review',
    'Поставьте оценку от 1 до 5 звёзд': 'Give a rating from 1 to 5 stars',
    'Комментарий не должен превышать 500 символов': 'The comment must not exceed 500 characters',
    'Удаление отзыва': 'Delete review',
    'Удалить этот отзыв? Это действие нельзя отменить.': 'Delete this review? This cannot be undone.',
    'Спасибо за отзыв!': 'Thank you for your review!',
    'Вы уже оставляли отзыв на этот товар': 'You have already reviewed this item',
    'Администратор не может оставлять отзывы': 'Administrators cannot post reviews',
    'Оценка должна быть целым числом от 1 до 5': 'The rating must be a whole number from 1 to 5',
    'Некорректный комментарий': 'Invalid comment',
    'Отзыв обновлён': 'Review updated',
    'Отзыв удалён': 'Review deleted',
    'Отзыв не найден': 'Review not found',
    'Нельзя изменять чужой отзыв': 'You cannot edit another user\u2019s review',
    'Нельзя удалять чужой отзыв': 'You cannot delete another user\u2019s review',
    'Некорректный идентификатор отзыва': 'Invalid review id',

    // Корзина
    'Итого, предметов:': 'Total items:',
    'Очистить': 'Clear',
    'Оформить покупку': 'Checkout',
    'Корзина пуста': 'The cart is empty',
    'Уменьшить количество': 'Decrease quantity',
    'Увеличить количество': 'Increase quantity',
    'Убрать из корзины': 'Remove from cart',
    'Убрать': 'Remove',
    'Уменьшите количество товаров, которых не хватает на складе': 'Reduce the quantity of items that are short in stock',
    'Войдите в аккаунт покупателя, чтобы пользоваться корзиной': 'Log in as a buyer to use the cart',
    'Товара нет в наличии': 'The item is out of stock',
    'Очистка корзины': 'Clear cart',
    'Убрать из корзины все товары?': 'Remove all items from the cart?',
    'Оформление покупки': 'Checkout',
    'Некорректный состав корзины': 'Invalid cart contents',
    'Один из товаров в корзине больше не продаётся': 'One of the items in the cart is no longer available',

    // Торговая площадка
    'Площадка': 'Market',
    'Площадка — MusorShop': 'Market — MusorShop',
    'Торговая площадка': 'Marketplace',
    'Здесь пользователи продают друг другу предметы из инвентаря. Комиссия магазина с каждой сделки:':
      'Here users sell inventory items to each other. Shop commission on every deal:',
    'Поиск по названию': 'Search by title',
    'Сортировка': 'Sorting',
    'Только мои лоты': 'My lots only',
    'Лотов:': 'Lots:',
    'Не удалось загрузить лоты': 'Failed to load lots',
    'ВАШ ЛОТ': 'YOUR LOT',
    'Снять с продажи': 'Remove from sale',
    'История цен': 'Price history',
    'У вас нет активных лотов': 'You have no active lots',
    'Лотов пока нет': 'No lots yet',
    'Покупка на площадке': 'Market purchase',
    'Продажа на площадке': 'Market sale',
    'Снятие лота': 'Remove lot',
    'Цена лота, ₽': 'Lot price, ₽',
    'Комиссия магазина:': 'Shop commission:',
    'Выставить на продажу': 'Put up for sale',
    'Введите цену, чтобы увидеть расчёт': 'Enter a price to see the calculation',
    'Не удалось загрузить историю цен': 'Failed to load price history',
    'Сделок': 'Deals',
    'Минимальная цена': 'Lowest price',
    'Средняя цена': 'Average price',
    'Максимальная цена': 'Highest price',
    'Товар больше не продаётся в магазине': 'The item is no longer sold in the shop',
    'Сделок на площадке пока не было': 'No market deals yet',
    'На площадку': 'To market',
    'На площадке': 'On the market',
    'НА ПЛОЩАДКЕ': 'ON THE MARKET',
    'ПРОДАНО НА ПЛОЩАДКЕ': 'SOLD ON THE MARKET',
    'Продано на площадке': 'Sold on the market',
    'с площадки': 'from the market',
    'На площадке нет ваших предметов': 'You have no items on the market',
    'Выставить на торговую площадку': 'Put up on the marketplace',
    'Мои лоты': 'My lots',
    'Покупки на площадке': 'Market purchases',
    'Продажи на площадке': 'Market sales',
    'Администратор не может торговать на площадке': 'Administrators cannot trade on the market',
    'Некорректный идентификатор предмета': 'Invalid item id',
    'Предмет не найден в инвентаре или уже недоступен': 'The item was not found in the inventory or is no longer available',
    'Предмет выставлен на продажу': 'The item has been put up for sale',
    'Некорректный идентификатор лота': 'Invalid lot id',
    'Лот не найден или уже неактивен': 'Lot not found or no longer active',
    'Лот снят с продажи': 'Lot removed from sale',
    'Лот не найден': 'Lot not found',
    'Нельзя купить собственный лот': 'You cannot buy your own lot',
    'Лот уже продан или снят с продажи': 'The lot has already been sold or removed',

    // Кейсы
    'Откройте кейс и получите случайный скин. Шансы выпадения каждого предмета указаны внутри кейса.':
      'Open a case and get a random skin. The drop chance of every item is shown inside the case.',
    'Добавить кейс': 'Add case',
    'Кейсов пока нет': 'No cases yet',
    'Не удалось загрузить кейсы': 'Failed to load cases',
    'Редактировать кейс': 'Edit case',
    'Удалить кейс': 'Delete case',
    'Содержимое кейса': 'Case contents',
    'Открыть': 'Open',
    'Войдите в аккаунт, чтобы открыть кейс': 'Log in to open the case',
    'Открываем…': 'Opening…',
    'Кейс пуст': 'The case is empty',
    'В кейсе нет предметов': 'There are no items in the case',
    'Вам выпало': 'You got',
    'Предмет добавлен в инвентарь в личном кабинете': 'The item has been added to the inventory in your account',
    'Войдите в аккаунт покупателя, чтобы открывать кейсы': 'Log in as a buyer to open cases',
    'Новый кейс': 'New case',
    'Цена открытия, ₽': 'Opening price, ₽',
    'Например, Стартовый кейс': 'For example, Starter case',
    'Ссылка на картинку (необязательно)': 'Image URL (optional)',
    'Предметы в кейсе (выбрано:': 'Items in the case (selected:',
    ', нужно минимум 2)': ', at least 2 required)',
    'Сначала добавьте товары в каталог': 'Add items to the catalog first',
    'Введите название кейса': 'Enter the case title',
    'Цена должна быть целым положительным числом': 'The price must be a positive whole number',
    'Выберите минимум 2 предмета': 'Select at least 2 items',
    'Удаление кейса': 'Delete case',
    'Кейс создан': 'Case created',
    'Кейс обновлён': 'Case updated',
    'Кейс удалён': 'Case deleted',
    'Кейс не найден': 'Case not found',
    'Этот кейс пуст': 'This case is empty',
    'Администратор не может открывать кейсы': 'Administrators cannot open cases',
    'Некорректный идентификатор кейса': 'Invalid case id',
    'Название кейса: от 1 до 60 символов': 'Case title: 1 to 60 characters',
    'Некорректный список предметов': 'Invalid item list',
    'Некоторые из выбранных товаров не найдены': 'Some of the selected items were not found'
  };

  // Перевод слова по словарю (для подстановки внутрь шаблонов)
  const d = (text) => (Object.prototype.hasOwnProperty.call(DICT, text) ? DICT[text] : text);

  // ---------- Шаблоны для строк с переменными частями ----------
  // Каждая запись: [регулярное выражение, функция, собирающая английский текст]
  const PATTERNS = [
    [/^(\S+@\S+) о товаре «(.+)»$/, (e, t) => `${e} on "${t}"`],
    [/^(\S+@\S+): ([+−].+) ₽\. Причина: (.+)$/, (e, a, r) => `${e}: ${a} ₽. Reason: ${r}`],
    [/^Ваш лот «(.+)» купили за (.+) ₽\. На баланс зачислено (.+) ₽$/, (t, p, g) => `Your lot "${t}" was bought for ${p} ₽. ${g} ₽ has been added to your balance`],
    [/^Администратор снял с продажи ваш лот «(.+)»\. Предмет возвращён в инвентарь$/, (t) => `An administrator removed your lot "${t}" from sale. The item was returned to your inventory`],
    [/^Администратор изменил ваш баланс: (.+) ₽\. Причина: (.+)$/, (a, r) => `An administrator changed your balance: ${a} ₽. Reason: ${r}`],
    [/^Администратор изменил ваш отзыв о товаре «(.+)»$/, (t) => `An administrator edited your review of "${t}"`],
    [/^Администратор удалил ваш отзыв о товаре «(.+)»$/, (t) => `An administrator deleted your review of "${t}"`],
    [/^Товар из избранного снова в наличии: «(.+)»$/, (t) => `A wishlist item is back in stock: "${t}"`],
    [/^До уровня (\d+) осталось (.+) XP\. Опыт даётся за покупки: 1 XP за каждые 100 ₽$/, (l, x) => `${x} XP to level ${l}. XP is earned by purchases: 1 XP per 100 ₽`],
    [/^Доступно (.+) ₽$/, (a) => `${a} ₽ available`],
    [/^серия дней: (\d+)$/, (n) => `day streak: ${n}`],
    [/^Серия дней: (\d+)$/, (n) => `Day streak: ${n}`],
    [/^Следующий бонус через (.+)$/, (t) => `Next bonus in ${t.replace(/ ч/g, ' h').replace(/ мин/g, ' min')}`],
    [/^Бонус получен: \+(.+) ₽$/, (a) => `Bonus claimed: +${a} ₽`],  
    [/^Выбрано: (\d+) из (\d+)$/, (a, b) => `Selected: ${a} of ${b}`],
    [/^(Армейское|Запрещённое|Засекреченное|Тайное) → (Запрещённое|Засекреченное|Тайное|Редкое)$/, (a, b) => `${d(a)} → ${d(b)}`],
    [/^Стоимость: (.+) ₽$/, (p) => `Value: ${p} ₽`],
    [/^Контракт выполнен: (.+)$/, (t) => `Contract completed: ${t}`],
    [/^Для контракта нужно выбрать ровно (\d+) разных предметов$/, (n) => `Exactly ${n} different items are required for a contract`],
    [/^Продавец: (.+)$/, (s) => `Seller: ${s}`],
    [/^Цена в магазине: (.+) ₽$/, (p) => `Shop price: ${p} ₽`],
    [/^Купить «(.+)» у продавца (.+) за (.+) ₽\?$/, (t, s, p) => `Buy "${t}" from ${s} for ${p} ₽?`],
    [/^Снять «(.+)» с продажи\? Предмет вернётся в инвентарь владельца\.$/, (t) => `Remove "${t}" from sale? The item will return to the owner's inventory.`],
    [/^Комиссия: (.+) ₽\. Вы получите: (.+) ₽$/, (f, g) => `Commission: ${f} ₽. You will receive: ${g} ₽`],
    [/^Магазин выкупит этот предмет за (.+) ₽$/, (p) => `The shop will buy this item for ${p} ₽`],
    [/^Предмет выставлен на продажу\. После продажи вы получите (.+) ₽$/, (p) => `The item has been put up for sale. You will receive ${p} ₽ after it sells`],
    [/^Одновременно можно держать не больше (\d+) лотов$/, (n) => `You can have at most ${n} active lots`],
    [/^(.+) \(комиссия (.+) ₽\)$/, (t, f) => `${t} (commission ${f} ₽)`],
    [/^В наличии: (\d+)$/, (n) => `In stock: ${n}`],
    [/^в наличии: (\d+)$/, (n) => `in stock: ${n}`],
    [/^«(.+)»: в наличии только (\d+) шт\.$/, (t, n) => `"${t}": only ${n} in stock`],
    [/^в наличии только (\d+) шт\.$/, (n) => `only ${n} in stock`],
    [/^(.+) ₽ за штуку$/, (p) => `${p} ₽ each`],
    [/^(\d+) шт\.$/, (n) => `${n} pcs`],
    [/^Пароль должен быть не короче (\d+) символов$/, (n) => `The password must be at least ${n} characters`],
    [/^Новый пароль должен быть не короче (\d+) символов$/, (n) => `The new password must be at least ${n} characters`],
    [/^Вы вошли как (.+)$/, (e) => `Logged in as ${e}`],
    [/^Купить «(.+)» за (.+) ₽\?$/, (t, p) => `Buy "${t}" for ${p} ₽?`],
    [/^Вы купили «(.+)»\. Остаток на балансе: (.+) ₽$/, (t, b) => `You bought "${t}". Remaining balance: ${b} ₽`],
    [/^Вы купили «(.+)»$/, (t) => `You bought "${t}"`],
    [/^Продать «(.+)» за (.+) ₽\? Это 80% от цены покупки\.$/, (t, p) => `Sell "${t}" for ${p} ₽? That is 80% of the purchase price.`],
    [/^Товар продан за (.+) ₽$/, (p) => `Item sold for ${p} ₽`],
    [/^Продать за (.+) ₽$/, (p) => `Sell for ${p} ₽`],
    [/^Баланс изменён\. Новый баланс: (.+) ₽$/, (b) => `Balance changed. New balance: ${b} ₽`],
    [/^Баланс: (.+) ₽$/, (b) => `Balance: ${b} ₽`],
    [/^Покупок: (\d+)$/, (n) => `Purchases: ${n}`],
    [/^Регистрация: (.+)$/, (date) => `Registered: ${date}`],
    [/^текущий баланс: (.+) ₽$/, (b) => `current balance: ${b} ₽`],
    [/^Максимальная сумма пополнения — (.+) ₽$/, (a) => `Maximum top-up amount: ${a} ₽`],
    [/^Баланс пополнен на (.+) ₽, бонус по промокоду: \+(.+) ₽ \((\d+)%\)$/, (a, b, p) => `Balance topped up by ${a} ₽, promo bonus: +${b} ₽ (${p}%)`],
    [/^Баланс пополнен на (.+) ₽$/, (a) => `Balance topped up by ${a} ₽`],
    [/^Промокод активирован: \+(.+) ₽$/, (a) => `Promo code redeemed: +${a} ₽`],
    [/^Этот промокод даёт \+(\d+)% к пополнению\. Введите сумму пополнения и нажмите «Применить»$/, (p) => `This promo code gives +${p}% on a top-up. Enter the top-up amount and press Apply`],
    [/^Промокод (\S+)( \(\+\d+%\))?$/, (code, extra) => `Promo code ${code}${extra || ''}`],
    [/^Корректировка администратором: (.+)$/, (r) => `Adjusted by an administrator: ${r}`],
    [/^Кейс «(.+)»: (.+)$/, (c, item) => `Case "${c}": ${item}`],
    [/^Удалить товар «(.+)»\? Это действие нельзя отменить\.$/, (t) => `Delete the item "${t}"? This cannot be undone.`],
    [/^Файл (.+) сохранён \(строк: (\d+)\)$/, (f, n) => `File ${f} saved (rows: ${n})`],
    [/^\+(\d+)% к пополнению$/, (p) => `+${p}% on top-up`],
    [/^Процент должен быть целым числом от 1 до (\d+)$/, (n) => `The percentage must be a whole number from 1 to ${n}`],
    [/^Бонус должен быть целым числом от 1 до (.+)$/, (n) => `The bonus must be a whole number from 1 to ${n}`],
    [/^Бонус не может превышать (.+) ₽$/, (n) => `The bonus cannot exceed ${n} ₽`],
    [/^Процент не может превышать (\d+)$/, (n) => `The percentage cannot exceed ${n}`],
    [/^Лимит активаций должен быть целым числом от 1 до (.+)$/, (n) => `The activation limit must be a whole number from 1 to ${n}`],
    [/^Заблокировать (.+)\? Он сразу потеряет доступ к аккаунту и не сможет войти\.$/, (e) => `Block ${e}? They will lose access immediately and will not be able to log in.`],
    [/^Разблокировать (.+)\? Он снова сможет войти в аккаунт\.$/, (e) => `Unblock ${e}? They will be able to log in again.`],
    [/^Сумма корректировки не может превышать (.+) ₽$/, (n) => `The adjustment cannot exceed ${n} ₽`],
    [/^Причина не должна превышать (\d+) символов$/, (n) => `The reason must not exceed ${n} characters`],
    [/^Не хватает (.+) ₽\. Пополните баланс$/, (n) => `${n} ₽ short. Top up your balance`],
    [/^После покупки на балансе останется (.+) ₽$/, (n) => `${n} ₽ will remain after the purchase`],
    [/^Больше (\d+) шт\. этого товара добавить нельзя$/, (n) => `You cannot add more than ${n} of this item`],
    [/^В корзине может быть не больше (\d+) разных товаров$/, (n) => `The cart can hold at most ${n} different items`],
    [/^В заказе может быть не больше (\d+) разных товаров$/, (n) => `An order can contain at most ${n} different items`],
    [/^«(.+)» добавлен в корзину$/, (t) => `"${t}" added to cart`],
    [/^Купить предметов: (\d+) на сумму (.+) ₽\?$/, (n, s) => `Buy ${n} items for ${s} ₽?`],
    [/^Куплено предметов: (\d+) на сумму (.+) ₽\. Остаток на балансе: (.+) ₽$/, (n, s, b) => `Items bought: ${n} for ${s} ₽. Remaining balance: ${b} ₽`],
    [/^Предметов: (\d+)$/, (n) => `Items: ${n}`],
    [/^Открыть за (.+) ₽$/, (p) => `Open for ${p} ₽`],
    [/^Средняя стоимость выпадающего предмета: (.+) ₽ при цене кейса (.+) ₽$/, (a, b) => `Average value of a dropped item: ${a} ₽ at a case price of ${b} ₽`],
    [/^стоимость (.+) ₽$/, (p) => `worth ${p} ₽`],
    [/^Выпало: (.+)$/, (t) => `You got: ${t}`],
    [/^Удалить кейс «(.+)»\? Уже выпавшие предметы останутся у пользователей\.$/, (t) => `Delete the case "${t}"? Items already dropped will stay with the users.`],
    [/^Цена должна быть целым числом от 1 до (.+)$/, (n) => `The price must be a whole number from 1 to ${n}`],
    [/^В кейсе должно быть от (\d+) до (\d+) предметов$/, (a, b) => `A case must contain ${a} to ${b} items`],
    [/^Тема: (Системная|Светлая|Тёмная)\. Нажмите, чтобы сменить$/, (m) => `Theme: ${d(m)}. Click to change`],
    [/^Тема оформления: (Системная|Светлая|Тёмная)$/, (m) => `Theme: ${d(m)}`],
    [/^(Оборот|Чистая прибыль|Покупок): (.+) (₽|шт\.)$/, (label, value, unit) => `${d(label)}: ${value} ${unit === '₽' ? '₽' : 'pcs'}`]
  ];

  // ---------- Перевод одной строки ----------

  // Перевод уже очищенной от лишних пробелов строки. Возвращает null, если перевода нет
  function translateCore(text) {
    if (Object.prototype.hasOwnProperty.call(DICT, text)) return DICT[text];

    for (const [regex, build] of PATTERNS) {
      const match = text.match(regex);
      if (match) return build(...match.slice(1));
    }
    return null;
  }

  // Перевод произвольного текста с сохранением пробелов по краям
  function translate(text) {
    const normalized = text.replace(/\s+/g, ' ').trim();

    // Пустые строки и строки без кириллицы (числа, email, английский текст) не трогаем
    if (!normalized || !/[А-Яа-яЁё]/.test(normalized)) return text;

    let result = translateCore(normalized);

    // Составные строки вида "часть · часть · часть" переводим по частям
    if (result === null && normalized.includes('·')) {
      let changed = false;
      const parts = normalized.split('·').map((part) => {
        const trimmed = part.trim();
        if (!trimmed) return '';
        const translated = translateCore(trimmed);
        if (translated !== null) {
          changed = true;
          return translated;
        }
        return trimmed;
      });
      if (changed) result = parts.join(' · ').trim();
    }

    if (result === null) return text; // перевода нет — оставляем как есть (например, название товара)

    const lead = /^\s/.test(text) ? ' ' : '';
    const trail = /\s$/.test(text) ? ' ' : '';
    return lead + result + trail;
  }

  // ---------- Текущий язык ----------

  let language = 'ru';
  try {
    if (localStorage.getItem('lang') === 'en') language = 'en';
  } catch (err) {
    // хранилище недоступно — остаёмся на русском
  }

  // ---------- Обработка страницы ----------

  // Для каждого текстового узла помним русский оригинал (ru) и то, что мы в него записали (out).
  // Если текущее содержимое узла не совпадает с out — значит, его изменило приложение,
  // и это новый русский оригинал
  const textState = new WeakMap();
  const attrState = new WeakMap();
  const TRANSLATED_ATTRS = ['placeholder', 'title', 'aria-label', 'alt'];
  const SKIP_SELECTOR = 'script, style, textarea, [data-no-i18n]';

  function processText(node) {
    const parent = node.parentElement;
    if (!parent || parent.closest(SKIP_SELECTOR)) return;

    const current = node.nodeValue;
    let state = textState.get(node);

    if (!state || current !== state.out) {
      state = { ru: current, out: current };
      textState.set(node, state);
    }

    const wanted = language === 'en' ? translate(state.ru) : state.ru;
    state.out = wanted;
    if (current !== wanted) node.nodeValue = wanted;
  }

  function processAttributes(element) {
    if (element.closest(SKIP_SELECTOR)) return;

    TRANSLATED_ATTRS.forEach((name) => {
      if (!element.hasAttribute(name)) return;

      const current = element.getAttribute(name);
      let states = attrState.get(element);
      if (!states) {
        states = {};
        attrState.set(element, states);
      }

      let state = states[name];
      if (!state || current !== state.out) {
        state = { ru: current, out: current };
        states[name] = state;
      }

      const wanted = language === 'en' ? translate(state.ru) : state.ru;
      state.out = wanted;
      if (current !== wanted) element.setAttribute(name, wanted);
    });
  }

  // Обработка элемента вместе со всем его содержимым
  function processTree(root) {
    if (root.nodeType === Node.TEXT_NODE) {
      processText(root);
      return;
    }
    if (root.nodeType !== Node.ELEMENT_NODE) return;

    processAttributes(root);
    root.querySelectorAll('[placeholder], [title], [aria-label], [alt]').forEach(processAttributes);

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node = walker.nextNode();
    while (node) {
      processText(node);
      node = walker.nextNode();
    }
  }

  // ---------- Наблюдение за изменениями страницы ----------

  const observerOptions = {
    subtree: true,
    childList: true,
    characterData: true,
    attributes: true,
    attributeFilter: TRANSLATED_ATTRS
  };

  const observer = new MutationObserver((records) => {
    // На время собственных правок отключаем наблюдение, иначе получится бесконечный цикл
    observer.disconnect();

    records.forEach((record) => {
      if (record.type === 'childList') {
        record.addedNodes.forEach(processTree);
      } else if (record.type === 'characterData') {
        processText(record.target);
      } else if (record.type === 'attributes') {
        processAttributes(record.target);
      }
    });

    observer.observe(document.documentElement, observerOptions);
  });

  // Полная обработка страницы (при загрузке и при смене языка)
  function applyLanguage() {
    observer.disconnect();
    document.documentElement.setAttribute('lang', language);
    processTree(document.documentElement);
    observer.observe(document.documentElement, observerOptions);
  }

  // ---------- Публичные функции ----------

  function setLanguage(next) {
    language = next === 'en' ? 'en' : 'ru';
    try {
      localStorage.setItem('lang', language);
    } catch (err) {
      // хранилище недоступно — язык не запомнится
    }

    applyLanguage();

    const select = document.getElementById('languageSelect');
    if (select) select.value = language;

    // Сообщаем приложению: то, что нарисовано не в HTML (график), нужно перерисовать
    window.dispatchEvent(new CustomEvent('i18n:change'));
  }

  window.i18n = {
    getLanguage: () => language,
    setLanguage,
    // Перевод строки для мест, которые не являются текстом страницы (график, CSV-файл)
    tr: (text) => (language === 'en' ? translate(String(text)).trim() : text)
  };

  // ---------- Запуск ----------

  const languageSelect = document.getElementById('languageSelect');
  if (languageSelect) {
    languageSelect.value = language;
    languageSelect.addEventListener('change', () => setLanguage(languageSelect.value));
  }

  applyLanguage();
})();