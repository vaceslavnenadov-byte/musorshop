// catalog.js
// Каталог: карточки товаров, поиск, сортировка, пагинация, редкость, скелетоны

// ==================== ТОВАРЫ ====================

// Загрузка товаров с сервера
async function loadProducts() {
  // При первой загрузке, пока товаров ещё нет, показываем карточки-скелетоны
  if (products.length === 0) {
    renderSkeletons();
  }

  try {
    products = await apiRequest('/products');
    renderProducts();
  } catch (err) {
    document.getElementById('productsGrid').innerHTML =
      '<p class="col-span-full text-center text-red-400 py-10">Не удалось загрузить товары</p>';
    showToast(err.message, 'error');
  }
}

// ---------- Состояние каталога ----------
const PAGE_SIZE = 8;      // товаров на странице
let searchQuery = '';     // текст поиска
let sortMode = 'newest';  // выбранная сортировка
let currentPage = 1;      // текущая страница

// Варианты сортировки: функция сравнения двух товаров
const SORTERS = {
  'newest':        (a, b) => new Date(b.createdAt) - new Date(a.createdAt),
  'price-asc':     (a, b) => a.price - b.price,
  'price-desc':    (a, b) => b.price - a.price,
  'title-asc':     (a, b) => a.title.localeCompare(b.title, 'ru'),
  'title-desc':    (a, b) => b.title.localeCompare(a.title, 'ru'),
  'quantity-desc': (a, b) => b.quantity - a.quantity
};

// Товары после поиска и сортировки (ещё без разбивки на страницы)
function getVisibleProducts() {
  const query = searchQuery.trim().toLowerCase();

  // Поиск по названию и описанию без учёта регистра
  const filtered = query
    ? products.filter((product) =>
        product.title.toLowerCase().includes(query) ||
        (product.description || '').toLowerCase().includes(query))
    : products;

  // Копируем массив ([...]), чтобы сортировка не меняла исходный список
  return [...filtered].sort(SORTERS[sortMode] || SORTERS.newest);
}

// HTML одной карточки товара
function createProductCard(product) {
  const isAdmin = currentUser && currentUser.role === 'admin';
  const isBuyer = currentUser && currentUser.role === 'user';
  const inStock = product.quantity > 0;
  const rarity = getRarity(product);

  const id = escapeHtml(product._id);
  const title = escapeHtml(product.title);
  const description = escapeHtml(product.description);

  // Картинка; если ссылки нет или она не загрузилась — показываем иконку-заглушку
  const placeholder = '<i class="fa-solid fa-image text-4xl text-gray-700"></i>';
  const image = product.imageUrl
    ? `<img src="${escapeHtml(product.imageUrl)}" alt="${title}" loading="lazy"
            class="w-full h-full object-contain p-3"
            onerror="this.replaceWith(Object.assign(document.createElement('i'), { className: 'fa-solid fa-image text-4xl text-gray-700' }))">`
    : placeholder;

  // Рейтинг (данные появятся на шаге 22)
  const rating = ratings[product._id];
  const ratingHtml = rating
    ? `<span class="text-yellow-500"><i class="fa-solid fa-star"></i> ${rating.average}</span>
       <span class="text-gray-500">(${rating.count})</span>`
    : '<span class="text-gray-500">Нет оценок</span>';

  // Сердечко избранного — только для покупателя
  const inWishlist = wishlistIds.has(product._id);
  const heartButton = isBuyer
    ? `<button type="button" data-action="wishlist" data-id="${id}"
               aria-label="${inWishlist ? 'Убрать из избранного' : 'Добавить в избранное'}"
               class="absolute top-2 left-2 w-9 h-9 rounded-full bg-gray-950/70 flex items-center justify-center transition
                      ${inWishlist ? 'text-red-500' : 'text-gray-400 hover:text-red-400'}">
         <i class="${inWishlist ? 'fa-solid' : 'fa-regular'} fa-heart"></i>
       </button>`
    : '';

  // Кнопки редактирования и удаления — только для админа, появляются при наведении
  const adminButtons = isAdmin
    ? `<div class="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition">
         <button type="button" data-action="edit" data-id="${id}" aria-label="Редактировать"
                 class="w-9 h-9 rounded-full bg-blue-600 hover:bg-blue-500 text-white">✎</button>
         <button type="button" data-action="delete" data-id="${id}" aria-label="Удалить"
                 class="w-9 h-9 rounded-full bg-red-600 hover:bg-red-500 text-white">✕</button>
       </div>`
    : '';

  // Кнопки "Купить" и "В корзину" — только для покупателя
  let buyButton = '';
  if (isBuyer) {
    const inCart = isInCart(product._id);
    buyButton = inStock
      ? `<button type="button" data-action="buy" data-id="${id}"
                 class="flex-1 py-2 rounded-lg bg-yellow-500 text-black text-sm font-semibold hover:bg-yellow-400 transition">
           Купить
         </button>
         <button type="button" data-action="cart" data-id="${id}"
                 aria-label="Добавить в корзину" title="${inCart ? 'Уже в корзине — добавить ещё' : 'Добавить в корзину'}"
                 class="shrink-0 w-10 rounded-lg border text-sm transition
                        ${inCart
                          ? 'bg-yellow-500/20 border-yellow-500 text-yellow-500'
                          : 'bg-gray-800 border-gray-700 text-gray-300 hover:border-yellow-500'}">
           <i class="fa-solid ${inCart ? 'fa-check' : 'fa-cart-plus'}"></i>
         </button>`
      : `<button type="button" disabled
                 class="flex-1 py-2 rounded-lg bg-gray-800 text-gray-500 text-sm font-semibold cursor-not-allowed">
           Нет в наличии
         </button>`;
  }

  return `
    <article class="group relative flex flex-col bg-gray-900 border border-gray-800 rounded-xl overflow-hidden hover:border-yellow-500/60 transition">
      <div class="relative h-44 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
        ${image}
        ${heartButton}
        ${adminButtons}
        ${product.statTrak
          ? '<span class="absolute bottom-3 left-2 px-2 py-0.5 rounded bg-orange-500 text-black text-[10px] font-bold">StatTrak™</span>'
          : ''}
        <!-- Цветная полоса редкости -->
        <div class="absolute bottom-0 inset-x-0 h-1" style="background:${rarity.color}"></div>
      </div>
      <div class="flex flex-col flex-1 p-4">
        <h3 class="font-semibold leading-snug">${title}</h3>
        <p class="text-xs font-medium" style="color:${rarity.color}">${rarity.label}</p>
        <p class="mt-1 text-sm">${ratingHtml}</p>
        <p class="mt-2 text-sm text-gray-400 line-clamp-2">${description}</p>
        <div class="mt-auto pt-4 flex items-end justify-between gap-2">
          <p class="text-xl font-bold text-yellow-500">${formatPrice(product.price)} ₽</p>
          <p class="text-xs ${inStock ? 'text-gray-400' : 'text-red-400'}">
            ${inStock ? `В наличии: ${product.quantity}` : 'Нет в наличии'}
          </p>
        </div>
        <div class="mt-3 flex gap-2">
          <button type="button" data-action="reviews" data-id="${id}"
                  class="flex-1 py-2 rounded-lg bg-gray-800 border border-gray-700 text-sm font-medium hover:bg-gray-700 transition">
            💬 Отзывы
          </button>
          ${buyButton}
        </div>
      </div>
    </article>`;
}

// Отрисовка сетки товаров с учётом поиска, сортировки и пагинации
function renderProducts() {
  const grid = document.getElementById('productsGrid');
  const emptyState = document.getElementById('emptyState');
  const isAdmin = currentUser && currentUser.role === 'admin';

  const list = getVisibleProducts();

  // Сколько всего страниц (минимум одна)
  const totalPages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  // Если текущая страница оказалась за пределами (например, удалили товар) — поправляем.
  // Пока товары не загружены, страницу не трогаем: иначе сбросится номер,
  // восстановленный после обновления вкладки
  if (products.length > 0) {
    currentPage = Math.min(Math.max(1, currentPage), totalPages);
    saveCatalogState();
  }

  // Поиск ничего не нашёл — показываем плашку
  const nothingFound = list.length === 0 && searchQuery.trim() !== '';
  emptyState.classList.toggle('hidden', !nothingFound);
  grid.classList.toggle('hidden', nothingFound);

  if (nothingFound) {
    grid.innerHTML = '';
    renderPagination(1);
    return;
  }

  // Вырезаем товары текущей страницы
  const start = (currentPage - 1) * PAGE_SIZE;
  const pageItems = list.slice(start, start + PAGE_SIZE);

  let html = pageItems.map(createProductCard).join('');

  // Карточка-плюсик для админа — только на последней странице
  if (isAdmin && currentPage === totalPages) {
    html += createAddCard();
  }

  if (!html) {
    html = '<p class="col-span-full text-center text-gray-500 py-10">Товаров пока нет</p>';
  }

  grid.innerHTML = html;
  renderPagination(totalPages);
}

// Один обработчик кликов на всю сетку (делегирование событий).
// По атрибуту data-action определяем, какая кнопка нажата
document.getElementById('productsGrid').addEventListener('click', (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;

  const handler = cardActions[button.dataset.action];
  if (handler) {
    handler(button.dataset.id, button);
  } else {
    showToast('Эта функция появится на следующих шагах', 'info');
  }
});

// ==================== ШАПКА: ЛОГОТИП И "ГЛАВНАЯ" ====================

function goHome(event) {
  if (event) event.preventDefault();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.getElementById('homeBtn').addEventListener('click', goHome);
document.getElementById('logoLink').addEventListener('click', goHome);

// ==================== ПОИСК, СОРТИРОВКА, ПАГИНАЦИЯ ====================

// Какие номера страниц показывать: первая, последняя и соседи текущей.
// Пропуски заменяются на "...". Пример: (20, 6) -> [1, '...', 5, 6, 7, '...', 20]
function getPageNumbers(totalPages, page) {
  const wanted = new Set([1, totalPages, page - 1, page, page + 1]);
  const pages = [...wanted]
    .filter((number) => number >= 1 && number <= totalPages)
    .sort((a, b) => a - b);

  const result = [];
  pages.forEach((number, index) => {
    if (index > 0) {
      const gap = number - pages[index - 1];
      if (gap === 2) {
        result.push(number - 1); // пропущена одна страница — показываем её, а не "..."
      } else if (gap > 2) {
        result.push('...');
      }
    }
    result.push(number);
  });
  return result;
}

// Отрисовка кнопок пагинации
function renderPagination(totalPages) {
  const container = document.getElementById('pagination');

  // Одна страница — пагинация не нужна
  if (totalPages <= 1) {
    container.innerHTML = '';
    return;
  }

  const baseClass = 'min-w-[2.5rem] px-3 py-2 rounded-lg text-sm font-medium transition';
  const normalClass = 'bg-gray-900 border border-gray-800 text-gray-300 hover:border-yellow-500';
  const activeClass = 'bg-yellow-500 text-black';
  const disabledClass = 'bg-gray-900 border border-gray-800 text-gray-600 cursor-not-allowed';

  const isFirst = currentPage === 1;
  const isLast = currentPage === totalPages;

  let html = `
    <button type="button" data-page="${currentPage - 1}" ${isFirst ? 'disabled' : ''}
            class="${baseClass} ${isFirst ? disabledClass : normalClass}">← Назад</button>`;

  getPageNumbers(totalPages, currentPage).forEach((item) => {
    if (item === '...') {
      html += '<span class="px-2 text-gray-500">…</span>';
    } else {
      html += `
        <button type="button" data-page="${item}" ${item === currentPage ? 'aria-current="page"' : ''}
                class="${baseClass} ${item === currentPage ? activeClass : normalClass}">${item}</button>`;
    }
  });

  html += `
    <button type="button" data-page="${currentPage + 1}" ${isLast ? 'disabled' : ''}
            class="${baseClass} ${isLast ? disabledClass : normalClass}">Вперёд →</button>`;

  container.innerHTML = html;
}

// Переход на страницу по клику (делегирование)
document.getElementById('pagination').addEventListener('click', (event) => {
  const button = event.target.closest('[data-page]');
  if (!button || button.disabled) return;

  currentPage = Number(button.dataset.page);
  renderProducts();

  // Плавно прокручиваем к началу сетки (с отступом под закреплённую шапку)
  const grid = document.getElementById('productsGrid');
  const top = grid.getBoundingClientRect().top + window.scrollY - 100;
  window.scrollTo({ top, behavior: 'smooth' });
});

// Дебаунс: функция вызывается только после паузы в delay мс.
// Благодаря этому поиск не запускается на каждую набранную букву
function debounce(fn, delay) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

// Поиск с задержкой 300 мс
document.getElementById('searchInput').addEventListener('input', debounce((event) => {
  searchQuery = event.target.value;
  currentPage = 1; // при новом запросе возвращаемся на первую страницу
  renderProducts();
}, 300));

// Смена сортировки
document.getElementById('sortSelect').addEventListener('change', (event) => {
  sortMode = event.target.value;
  currentPage = 1;
  renderProducts();
});

// Кнопка "Главная" и логотип сбрасывают поиск, сортировку и страницу
function resetCatalog() {
  searchQuery = '';
  sortMode = 'newest';
  currentPage = 1;
  document.getElementById('searchInput').value = '';
  document.getElementById('sortSelect').value = 'newest';
  renderProducts();
}

document.getElementById('homeBtn').addEventListener('click', resetCatalog);
document.getElementById('logoLink').addEventListener('click', resetCatalog);

// ==================== СКЕЛЕТОНЫ ЗАГРУЗКИ ====================

// Серые мерцающие карточки-заготовки на время загрузки товаров
function renderSkeletons() {
  const card = `
    <div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden animate-pulse" aria-hidden="true">
      <div class="h-44 bg-gray-800"></div>
      <div class="p-4 space-y-3">
        <div class="h-4 w-3/4 rounded bg-gray-800"></div>
        <div class="h-3 w-1/3 rounded bg-gray-800"></div>
        <div class="h-3 rounded bg-gray-800"></div>
        <div class="h-6 w-1/2 rounded bg-gray-800"></div>
        <div class="h-9 rounded bg-gray-800"></div>
      </div>
    </div>`;

  // Столько же карточек, сколько помещается на странице
  document.getElementById('productsGrid').innerHTML = card.repeat(PAGE_SIZE);
}

// ==================== РЕДКОСТЬ СКИНОВ ====================

// Справочник редкостей: подпись и цвет (как в CS2)
const RARITY_INFO = {
  milspec:    { label: 'Армейское',     color: '#4b69ff' },
  restricted: { label: 'Запрещённое',   color: '#8847ff' },
  classified: { label: 'Засекреченное', color: '#d32ce6' },
  covert:     { label: 'Тайное',        color: '#eb4b4b' },
  gold:       { label: 'Редкое',        color: '#e4ae39' }
};

// Редкость предмета: { key, label, color }. У старых товаров без редкости — "Армейское"
function getRarity(item) {
  const key = item && RARITY_INFO[item.rarity] ? item.rarity : 'milspec';
  return { key, ...RARITY_INFO[key] };
}

// ==================== ЗАПОМИНАНИЕ СОСТОЯНИЯ КАТАЛОГА ====================

// Сортировка — личная настройка, храним в localStorage (сохраняется надолго).
// Страница и поиск — в sessionStorage (живут, пока открыта вкладка, и переживают F5)
function saveCatalogState() {
  try {
    localStorage.setItem('catalogSort', sortMode);
    sessionStorage.setItem('catalogView', JSON.stringify({ page: currentPage, search: searchQuery }));
  } catch (err) {
    // хранилище недоступно — просто не запоминаем
  }
}

// Восстановление при загрузке страницы. Этот код выполняется раньше,
// чем придут товары с сервера, поэтому первая отрисовка уже учтёт сохранённое
(function restoreCatalogState() {
  try {
    const savedSort = localStorage.getItem('catalogSort');
    if (savedSort && SORTERS[savedSort]) {
      sortMode = savedSort;
      document.getElementById('sortSelect').value = savedSort;
    }

    const saved = JSON.parse(sessionStorage.getItem('catalogView') || 'null');
    if (saved) {
      if (typeof saved.search === 'string') {
        searchQuery = saved.search.slice(0, 100);
        document.getElementById('searchInput').value = searchQuery;
      }
      if (Number.isInteger(saved.page) && saved.page > 0) {
        currentPage = saved.page;
      }
    }
  } catch (err) {
    // повреждённые данные игнорируем — каталог откроется в обычном виде
  }
})();

// ==================== КАТЕГОРИЯ И КАЧЕСТВО ====================

// Категории оружия (те же ключи, что на сервере)
const CATEGORY_INFO = {
  rifle:  'Винтовки',
  sniper: 'Снайперские винтовки',
  pistol: 'Пистолеты',
  smg:    'Пистолеты-пулемёты',
  heavy:  'Тяжёлое оружие',
  knife:  'Ножи',
  gloves: 'Перчатки',
  other:  'Другое'
};

// Качество (износ) — названия как в игре, не переводятся
const WEAR_INFO = {
  fn: 'Factory New',
  mw: 'Minimal Wear',
  ft: 'Field-Tested',
  ww: 'Well-Worn',
  bs: 'Battle-Scarred'
};

// Строка характеристик для карточки: "Field-Tested · Винтовки".
// Категорию "Другое" и неуказанное качество не показываем
function getProductMeta(product) {
  const parts = [];
  if (WEAR_INFO[product.wear]) parts.push(WEAR_INFO[product.wear]);
  if (CATEGORY_INFO[product.category] && product.category !== 'other') {
    parts.push(CATEGORY_INFO[product.category]);
  }
  return parts.join(' · ');
}

