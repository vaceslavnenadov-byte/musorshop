// Редкости скинов. weight — вес при выпадении из кейса (чем больше, тем чаще).
// Пропорции взяты из CS2: сумма весов 10000, то есть 7992 = 79,92%
const RARITIES = {
  milspec:    { label: 'Армейское',     weight: 7992 },
  restricted: { label: 'Запрещённое',   weight: 1598 },
  classified: { label: 'Засекреченное', weight: 320 },
  covert:     { label: 'Тайное',        weight: 64 },
  gold:       { label: 'Редкое',        weight: 26 }
};

const RARITY_KEYS = Object.keys(RARITIES);
const DEFAULT_RARITY = 'milspec';

module.exports = { RARITIES, RARITY_KEYS, DEFAULT_RARITY };