// Скрипт наполнения базы демо-товарами.
// Запуск из папки backend: node seed.js
require('dotenv').config();

const mongoose = require('mongoose');
const Product = require('./models/Product');

// Картинки пока пустые — на сайте будет иконка-заглушка.
// Настоящие ссылки можно будет вставить через редактирование товара (шаг 15)
const demoProducts = [
  { title: 'AK-47 | Redline', description: 'Field-Tested. Классика с красными полосами на карбоне.', price: 2900, quantity: 12 },
  { title: 'AWP | Asiimov', description: 'Field-Tested. Футуристичный бело-оранжевый дизайн.', price: 11500, quantity: 5 },
  { title: 'M4A4 | Neo-Noir', description: 'Minimal Wear. Нуарная иллюстрация в сине-розовых тонах.', price: 4200, quantity: 8 },
  { title: 'M4A1-S | Printstream', description: 'Factory New. Чёрно-белый перламутровый скин.', price: 24000, quantity: 3 },
  { title: 'Desert Eagle | Blaze', description: 'Factory New. Языки пламени на чёрном корпусе.', price: 58000, quantity: 2 },
  { title: 'USP-S | Kill Confirmed', description: 'Minimal Wear. Рисунок черепа и пули.', price: 9800, quantity: 6 },
  { title: 'Glock-18 | Fade', description: 'Factory New. Градиент от розового к жёлтому.', price: 135000, quantity: 1 },
  { title: 'AK-47 | Vulcan', description: 'Field-Tested. Спортивный бело-синий дизайн.', price: 31000, quantity: 4 },
  { title: 'AWP | Dragon Lore', description: 'Field-Tested. Легендарный скин с драконом.', price: 890000, quantity: 1 },
  { title: 'P250 | See Ya Later', description: 'Factory New. Мультяшный рисунок на жёлтом фоне.', price: 1200, quantity: 15 },
  { title: 'MP9 | Starlight Protector', description: 'Minimal Wear. Золотой орнамент на белом.', price: 3400, quantity: 9 },
  { title: 'Five-SeveN | Hyper Beast', description: 'Field-Tested. Яркий монстр в неоновых цветах.', price: 2100, quantity: 0 }
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ MongoDB подключена');

    // Не дублируем товары при повторном запуске
    const count = await Product.countDocuments();
    if (count > 0) {
      console.log(`ℹ️ В базе уже есть товары (${count} шт.), ничего не добавлено`);
      return;
    }

    // Разносим даты создания на минуту, чтобы работала сортировка "по новизне"
    const now = Date.now();
    const docs = demoProducts.map((product, index) => ({
      ...product,
      imageUrl: '',
      createdAt: new Date(now - index * 60 * 1000)
    }));

    await Product.insertMany(docs);
    console.log(`✅ Добавлено товаров: ${docs.length}`);
  } catch (err) {
    console.error('❌ Ошибка:', err.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}

seed();