const mongoose = require('mongoose');
const { RARITY_KEYS, DEFAULT_RARITY } = require('../config/rarities');
const { CATEGORY_KEYS, WEAR_KEYS, DEFAULT_CATEGORY } = require('../config/productOptions');



// Схема товара (скина)
const productSchema = new mongoose.Schema({
  // Название скина
  title: {
    type: String,
    required: true,
    trim: true
  },
  // Описание
  description: {
    type: String,
    default: '',
    trim: true
  },
  // Цена в рублях, не может быть отрицательной
  price: {
    type: Number,
    required: true,
    min: 0
  },
  // Остаток на складе
  quantity: {
    type: Number,
    required: true,
    min: 0,
    default: 0
  },
  // Ссылка на картинку
  imageUrl: {
    type: String,
    default: '',
    trim: true
  },
  // Редкость скина: влияет на цвет полосы на карточке и на шанс выпадения из кейса
  rarity: {
    type: String,
    enum: RARITY_KEYS,
    default: DEFAULT_RARITY
  },
    // Категория оружия (для фильтра в каталоге)
  category: {
    type: String,
    enum: CATEGORY_KEYS,
    default: DEFAULT_CATEGORY
  },
  // Качество (износ). Пустая строка — качество не указано
  wear: {
    type: String,
    enum: [...WEAR_KEYS, ''],
    default: ''
  },
  // Версия со счётчиком убийств StatTrak™
  statTrak: {
    type: Boolean,
    default: false
  },
  // Дата добавления — ставится автоматически
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Экспортируем модель; коллекция в базе будет называться "products"
module.exports = mongoose.model('Product', productSchema);