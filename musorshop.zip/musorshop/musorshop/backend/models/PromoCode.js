const mongoose = require('mongoose');

// Схема промокода
const promoCodeSchema = new mongoose.Schema({
  // Сам код: хранится в верхнем регистре, уникален
  code: {
    type: String,
    required: true,
    unique: true,
    uppercase: true,
    trim: true
  },
  // Тип промокода: fixed — фиксированная сумма, percent — процент от пополнения
  type: {
    type: String,
    enum: ['fixed', 'percent'],
    default: 'fixed'
  },
  // Размер бонуса: рубли для fixed, проценты для percent
  amount: {
    type: Number,
    required: true,
    min: 1
  },
  // Сколько раз код можно активировать всего (разными пользователями)
  maxUses: {
    type: Number,
    required: true,
    min: 1
  },
  // Кто уже активировал код — по этому списку запрещаем повторную активацию
  usedBy: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('PromoCode', promoCodeSchema);