const mongoose = require('mongoose');

// Запись журнала: одно действие администратора
const adminActionSchema = new mongoose.Schema({
  // Кто выполнил действие
  adminId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  // Код действия вида "раздел.операция": product.create, user.block и т.д.
  action: {
    type: String,
    required: true
  },
  // Раздел (первая часть кода) — хранится отдельно для быстрого фильтра
  category: {
    type: String,
    required: true
  },
  // Над чем выполнено действие: название товара, код промокода, email пользователя
  target: {
    type: String,
    default: '',
    maxlength: 500
  },
    // Подробности: changes — список изменённых полей [{ field, before, after }],
  // snapshot — данные объекта на момент создания или удаления
  details: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

adminActionSchema.index({ createdAt: -1 });
adminActionSchema.index({ category: 1, createdAt: -1 });

module.exports = mongoose.model('AdminAction', adminActionSchema);