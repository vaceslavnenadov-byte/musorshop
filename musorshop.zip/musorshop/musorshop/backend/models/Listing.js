const mongoose = require('mongoose');

// Лот на торговой площадке: предмет из инвентаря, выставленный пользователем на продажу
const listingSchema = new mongoose.Schema({
  sellerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  // Кто купил (заполняется при продаже)
  buyerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  // Запись инвентаря продавца, которая выставлена на продажу
  purchaseId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Purchase',
    required: true
  },
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  // Данные предмета копируем в лот: он не должен зависеть от изменений товара в магазине
  productTitle: { type: String, required: true },
  productImage: { type: String, default: '' },
  rarity: { type: String, default: 'milspec' },
  wear: { type: String, default: '' },
  statTrak: { type: Boolean, default: false },
  // Стоимость предмета в магазине (от неё считается выкуп за 80%).
  // При продаже на площадке она переходит к покупателю без изменений
  itemValue: { type: Number, required: true, min: 0 },
  // Цена, назначенная продавцом
  price: { type: Number, required: true, min: 1 },
  // Комиссия магазина с этой сделки
  fee: { type: Number, required: true, min: 0 },
  // active — продаётся, sold — куплен, cancelled — снят с продажи
  status: {
    type: String,
    enum: ['active', 'sold', 'cancelled'],
    default: 'active'
  },
  createdAt: { type: Date, default: Date.now },
  soldAt: { type: Date }
});

// Индексы: список активных лотов по дате и история сделок по товару
listingSchema.index({ status: 1, createdAt: -1 });
listingSchema.index({ productId: 1, status: 1, soldAt: -1 });

module.exports = mongoose.model('Listing', listingSchema);