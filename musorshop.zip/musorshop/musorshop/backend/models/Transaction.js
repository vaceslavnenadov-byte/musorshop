const mongoose = require('mongoose');

// Типы операций. adjustment и case понадобятся на следующих шагах
const TRANSACTION_TYPES = [
  'deposit', 'purchase', 'sale', 'promo', 'adjustment', 'case',
  'market_buy', 'market_sale', 'bonus'
];

// Схема операции — одна запись о движении денег на балансе
const transactionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  type: {
    type: String,
    enum: TRANSACTION_TYPES,
    required: true
  },
  // Сумма со знаком: плюс — зачисление, минус — списание
  amount: {
    type: Number,
    required: true
  },
  // Баланс пользователя сразу после операции
  balanceAfter: {
    type: Number,
    required: true
  },
  // Пояснение: название товара, код промокода и т.п.
  description: {
    type: String,
    default: ''
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Индекс для быстрой выборки истории одного пользователя по дате
transactionSchema.index({ userId: 1, createdAt: -1 });

const Transaction = mongoose.model('Transaction', transactionSchema);

module.exports = Transaction;
module.exports.TRANSACTION_TYPES = TRANSACTION_TYPES;