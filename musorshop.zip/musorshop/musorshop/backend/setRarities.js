// Скрипт: назначает редкость товарам, у которых она ещё не указана, исходя из цены.
// Запуск из папки backend: node setRarities.js
require('dotenv').config();

const mongoose = require('mongoose');
const Product = require('./models/Product');

// Чем дороже скин, тем выше редкость
function rarityByPrice(price) {
  if (price >= 200000) return 'gold';
  if (price >= 50000) return 'covert';
  if (price >= 15000) return 'classified';
  if (price >= 4000) return 'restricted';
  return 'milspec';
}

async function main() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ MongoDB подключена');

    // Только товары, где поля rarity ещё нет в базе
    const products = await Product.find({ rarity: { $exists: false } });

    for (const product of products) {
      product.rarity = rarityByPrice(product.price);
      await product.save();
      console.log(`  ${product.title} → ${product.rarity}`);
    }

    console.log(`✅ Обновлено товаров: ${products.length}`);
  } catch (err) {
    console.error('❌ Ошибка:', err.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}

main();