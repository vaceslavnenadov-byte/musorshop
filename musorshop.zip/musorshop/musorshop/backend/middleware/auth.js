const jwt = require('jsonwebtoken');
const User = require('../models/User');

const COOKIE_NAME = 'musorshop_token';
const COOKIE_MAX_AGE = 24 * 60 * 60 * 1000; // 1 день, как и срок жизни токена

// Параметры cookie:
//   httpOnly — недоступна из JavaScript (защита токена от кражи при XSS)
//   sameSite: 'strict' — не отправляется при запросах с чужих сайтов (защита от CSRF)
//   secure — только по HTTPS; включается при выкладке в интернет
function cookieOptions() {
  return {
    httpOnly: true,
    sameSite: 'strict',
    secure: process.env.NODE_ENV === 'production',
    path: '/'
  };
}

function setAuthCookie(res, token) {
  res.cookie(COOKIE_NAME, token, { ...cookieOptions(), maxAge: COOKIE_MAX_AGE });
}

function clearAuthCookie(res) {
  res.clearCookie(COOKIE_NAME, cookieOptions());
}

// Чтение одной cookie из заголовка запроса
function readCookie(req, name) {
  const header = req.headers.cookie;
  if (!header) return null;

  for (const part of header.split(';')) {
    const index = part.indexOf('=');
    if (index === -1) continue;
    if (part.slice(0, index).trim() === name) {
      try {
        return decodeURIComponent(part.slice(index + 1).trim());
      } catch (err) {
        return null;
      }
    }
  }
  return null;
}

// Токен берём из заголовка Authorization (так работают автотесты и сторонние клиенты)
// или из cookie (так работает сайт в браузере)
function getTokenFromRequest(req) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return { token: authHeader.split(' ')[1], fromCookie: false };
  }

  const cookieToken = readCookie(req, COOKIE_NAME);
  return cookieToken ? { token: cookieToken, fromCookie: true } : null;
}

// Создание токена на 1 день. Внутри — id, роль и версия токена
function signToken(user) {
  return jwt.sign(
    { id: user._id, role: user.role, v: user.tokenVersion || 0 },
    process.env.JWT_SECRET,
    { expiresIn: '1d' }
  );
}

// Проверка токена: пускает дальше только авторизованных пользователей
async function verifyToken(req, res, next) {
  const found = getTokenFromRequest(req);
  if (!found) {
    return res.status(401).json({ message: 'Требуется авторизация' });
  }

  // Отказ в доступе; негодную cookie заодно удаляем из браузера
  const reject = (message) => {
    if (found.fromCookie) clearAuthCookie(res);
    return res.status(401).json({ message });
  };

  let decoded;
  try {
    // Проверяем подпись и срок жизни токена
    decoded = jwt.verify(found.token, process.env.JWT_SECRET);
  } catch (err) {
    return reject('Недействительный или просроченный токен');
  }

  try {
    // Сверяемся с базой: пользователь существует, и токен выдан после последней смены пароля
    const user = await User.findById(decoded.id).select('role tokenVersion isBlocked');

    if (!user || (decoded.v || 0) !== (user.tokenVersion || 0)) {
      return reject('Сессия завершена. Войдите заново');
    }

    // Заблокированный пользователь теряет доступ сразу, не дожидаясь истечения токена
    if (user.isBlocked) {
      return reject('Аккаунт заблокирован администратором');
    }

    // Роль берём из базы, а не из токена — она всегда актуальна
    req.user = { id: user._id.toString(), role: user.role };
    next();
  } catch (err) {
    console.error('Ошибка проверки токена:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
}

// Проверка роли: пускает дальше только администратора
// Используется ПОСЛЕ verifyToken, так как опирается на req.user
function isAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Доступ только для администратора' });
  }
  next();
}

// Необязательная авторизация: если пришёл действующий токен — запоминаем пользователя,
// если токена нет или он негоден — запрос идёт дальше как гостевой
async function optionalToken(req, res, next) {
  const found = getTokenFromRequest(req);
  if (!found) return next();

  try {
    const decoded = jwt.verify(found.token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('role tokenVersion isBlocked');

    if (user && !user.isBlocked && (decoded.v || 0) === (user.tokenVersion || 0)) {
      req.user = { id: user._id.toString(), role: user.role };
    }
  } catch (err) {
    // негодный токен — считаем запрос гостевым
  }
  next();
}

module.exports = { verifyToken, optionalToken, isAdmin, signToken, setAuthCookie, clearAuthCookie };