const Notification = require('../models/Notification');
const Wishlist = require('../models/Wishlist');
const { sendToUser } = require('./realtime');

// Уведомление в том виде, в каком оно уходит в браузер
function toPublic(notification) {
  return {
    id: notification._id,
    type: notification.type,
    text: notification.text,
    read: notification.read,
    createdAt: notification.createdAt
  };
}

// Создать уведомление: сохранить в базе и, если пользователь сейчас на сайте,
// сразу доставить по открытому соединению.
// Ошибка уведомления не должна ломать операцию, которая его вызвала
async function notify(userId, type, text) {
  try {
    const notification = await Notification.create({ userId, type, text });
    sendToUser(userId, 'notification', toPublic(notification));
  } catch (err) {
    console.error('Не удалось создать уведомление:', err.message);
  }
}

// Товар снова в наличии: уведомляем всех, у кого он в избранном.
// excludeUserId — кого не уведомлять (например, того, кто сам вернул предмет на витрину)
async function notifyRestock(product, excludeUserId = null) {
  try {
    const entries = await Wishlist.find({ productId: product._id }).select('userId');
    for (const entry of entries) {
      if (excludeUserId && String(entry.userId) === String(excludeUserId)) continue;
      await notify(entry.userId, 'restock', `Товар из избранного снова в наличии: «${product.title}»`);
    }
  } catch (err) {
    console.error('Не удалось разослать уведомления о наличии:', err.message);
  }
}

module.exports = { notify, notifyRestock, toPublic };