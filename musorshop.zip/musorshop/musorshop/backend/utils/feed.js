const Purchase = require('../models/Purchase');
const Product = require('../models/Product');
const User = require('../models/User');
const { broadcast } = require('./realtime');
const { maskEmail } = require('./format');

// Одна запись ленты в том виде, в каком она уходит в браузер
function makeFeedItem({ email, title, rarity, price, source, at }) {
  return {
    user: maskEmail(email),          // полный email в ленту не попадает
    title,
    rarity: rarity || 'milspec',
    price,
    source: source || 'shop',        // shop | case | market | contract
    at: at || new Date()
  };
}

// Последние события для только что подключившегося посетителя.
// Берутся из базы, поэтому лента не пустеет после перезапуска сервера
async function getRecentFeed(limit = 15) {
  const purchases = await Purchase.find()
    .sort({ purchasedAt: -1 })
    .limit(limit)
    .populate('userId', 'email');

  // Редкость хранится в товаре — подтягиваем её одним запросом
  const productIds = [...new Set(purchases.map((purchase) => String(purchase.productId)))];
  const products = await Product.find({ _id: { $in: productIds } }).select('rarity');
  const rarityById = new Map(products.map((product) => [String(product._id), product.rarity]));

  return purchases.map((purchase) => makeFeedItem({
    email: purchase.userId ? purchase.userId.email : '',
    title: purchase.productTitle,
    rarity: rarityById.get(String(purchase.productId)),
    price: purchase.price,
    source: purchase.source,
    at: purchase.purchasedAt
  }));
}

// Публикация нового события всем посетителям.
// Передаётся либо документ пользователя (user), либо только его id (userId).
// Ошибки здесь не должны влиять на покупку, поэтому функция ничего не выбрасывает
function publishFeed({ user, userId, title, rarity, price, source }) {
  const send = (email) => {
    try {
      broadcast('feed:new', makeFeedItem({ email, title, rarity, price, source }));
    } catch (err) {
      console.error('Не удалось отправить событие ленты:', err.message);
    }
  };

  if (user && user.email) {
    return send(user.email);
  }

  User.findById(userId).select('email')
    .then((found) => send(found ? found.email : ''))
    .catch(() => {});
}

module.exports = { getRecentFeed, publishFeed };