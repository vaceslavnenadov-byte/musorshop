// Рассылка событий в реальном времени по технологии Server-Sent Events (SSE).
// Браузер открывает одно долгое соединение, сервер по мере появления событий
// дописывает в него сообщения вида:
//
//   event: имя_события
//   data: {"json":"с данными"}
//   (пустая строка)

const MAX_CLIENTS = 500;     // предел одновременных соединений
const HEARTBEAT_MS = 25000;  // как часто слать "пульс", чтобы соединение не закрыли по простою

// Подключённые клиенты: { res — открытый ответ, userId — пользователь или null для гостя }
const clients = new Set();

function canAcceptClient() {
  return clients.size < MAX_CLIENTS;
}

// Отправка одного события в одно соединение
function sendEvent(res, event, data) {
  res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
}

// Регистрация нового соединения
function addClient(req, res, userId) {
  res.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no' // просим промежуточные серверы не накапливать ответ
  });
  res.flushHeaders();

  const client = { res, userId: userId ? String(userId) : null };
  clients.add(client);

  // Строка, начинающаяся с двоеточия, — комментарий: браузер её игнорирует,
  // но соединение считается активным
  const heartbeat = setInterval(() => res.write(': ping\n\n'), HEARTBEAT_MS);

  // Клиент закрыл вкладку или соединение оборвалось
  req.on('close', () => {
    clearInterval(heartbeat);
    clients.delete(client);
  });

  return client;
}

// Событие всем подключённым
function broadcast(event, data) {
  for (const client of clients) {
    sendEvent(client.res, event, data);
  }
}

// Событие одному пользователю (во все его открытые вкладки)
function sendToUser(userId, event, data) {
  const target = String(userId);
  for (const client of clients) {
    if (client.userId === target) sendEvent(client.res, event, data);
  }
}

module.exports = { canAcceptClient, addClient, sendEvent, broadcast, sendToUser };