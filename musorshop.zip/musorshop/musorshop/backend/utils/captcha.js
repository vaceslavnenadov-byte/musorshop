const crypto = require('crypto');
const svgCaptcha = require('svg-captcha');

const CAPTCHA_TTL = 5 * 60 * 1000; // код действует 5 минут
const MAX_CAPTCHAS = 5000;         // предел хранилища, чтобы его нельзя было переполнить запросами

// Выданные коды: идентификатор → { answer, expiresAt }.
// Хранятся в памяти сервера; при перезапуске сбрасываются — пользователь просто получит новый код
const store = new Map();

// Удаление просроченных кодов
function purgeExpired() {
  const now = Date.now();
  for (const [id, entry] of store) {
    if (entry.expiresAt <= now) store.delete(id);
  }
}

// Создание нового кода. Возвращает идентификатор, картинку (SVG) и сам текст
function createCaptcha() {
  purgeExpired();

  // Хранилище заполнено — вытесняем самый старый код
  if (store.size >= MAX_CAPTCHAS) {
    store.delete(store.keys().next().value);
  }

  const captcha = svgCaptcha.create({
    size: 5,                     // количество символов
    noise: 3,                    // количество мешающих линий
    color: true,                 // разноцветные символы
    ignoreChars: '0oO1iIlL',     // убираем символы, которые легко перепутать
    width: 160,
    height: 56,
    fontSize: 52,
    background: '#f3f4f6'
  });

  const id = crypto.randomBytes(16).toString('hex');
  store.set(id, {
    answer: captcha.text.toLowerCase(),
    expiresAt: Date.now() + CAPTCHA_TTL
  });

  return { id, svg: captcha.data, text: captcha.text };
}

// Проверка ответа. Код одноразовый: после любой попытки он удаляется,
// поэтому подбирать ответ к одной и той же картинке нельзя
function verifyCaptcha(id, answer) {
  if (typeof id !== 'string' || typeof answer !== 'string') return false;

  const entry = store.get(id);
  if (!entry) return false;

  store.delete(id);

  if (entry.expiresAt <= Date.now()) return false;
  return entry.answer === answer.trim().toLowerCase(); // регистр букв не важен
}

// Middleware: пропускает запрос дальше только с верным кодом.
// Ожидает в теле запроса поля captchaId и captchaAnswer
function requireCaptcha(req, res, next) {
  // В автотестах капча по умолчанию отключена (тесты не видят картинку).
  // Отдельная группа тестов включает её переменной CAPTCHA_ENFORCE
  if (process.env.NODE_ENV === 'test' && process.env.CAPTCHA_ENFORCE !== '1') {
    return next();
  }

  const { captchaId, captchaAnswer } = req.body || {};

  if (typeof captchaAnswer !== 'string' || !captchaAnswer.trim()) {
    return res.status(400).json({ message: 'Введите код с картинки' });
  }
  if (!verifyCaptcha(captchaId, captchaAnswer)) {
    return res.status(400).json({ message: 'Код с картинки введён неверно. Попробуйте ещё раз' });
  }

  next();
}

module.exports = { createCaptcha, requireCaptcha };