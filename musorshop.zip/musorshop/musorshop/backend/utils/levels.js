const User = require('../models/User');

// ---------- Уровни ----------

const XP_BASE = 500;       // множитель кривой уровней
const XP_PER_RUBLES = 100; // 1 XP за каждые 100 ₽ трат

// Уровень по накопленному опыту. Порог уровня L равен 500 × (L − 1)²:
// 2-й уровень — 500 XP, 3-й — 2000, 4-й — 4500, то есть каждый следующий даётся труднее
function getLevel(xp) {
  return Math.floor(Math.sqrt(Math.max(0, xp) / XP_BASE)) + 1;
}

function levelStartXp(level) {
  return XP_BASE * (level - 1) ** 2;
}

// Сведения об уровне для показа: сам уровень и прогресс внутри него
function getLevelInfo(xp) {
  const level = getLevel(xp);
  const start = levelStartXp(level);
  const next = levelStartXp(level + 1);

  return {
    level,
    xp,
    levelXp: xp - start,      // сколько набрано внутри текущего уровня
    levelSize: next - start,  // сколько всего нужно на этот уровень
    toNext: next - xp         // сколько осталось до следующего
  };
}

// Сколько опыта даёт трата суммы amount
function xpForSpend(amount) {
  return Math.floor(amount / XP_PER_RUBLES);
}

// Начисление опыта. Ошибка здесь не должна ломать покупку, поэтому только пишем её в консоль
async function addXp(userId, amount) {
  if (!amount || amount <= 0) return;
  try {
    await User.updateOne({ _id: userId }, { $inc: { xp: amount } });
  } catch (err) {
    console.error('Не удалось начислить опыт:', err.message);
  }
}

// ---------- Ежедневный бонус ----------

const BONUS_BASE = 500;                        // бонус на первом уровне
const BONUS_PER_LEVEL = 100;                   // прибавка за каждый следующий уровень
const BONUS_MAX_BASE = 5000;                   // предел базовой суммы
const BONUS_XP = 25;                           // опыт за получение бонуса
const BONUS_COOLDOWN = 24 * 60 * 60 * 1000;    // бонус раз в 24 часа
const STREAK_WINDOW = 48 * 60 * 60 * 1000;     // серия сохраняется, если прошло меньше 48 часов
const STREAK_MAX = 7;                          // серия растёт до 7 дней
const STREAK_STEP = 0.1;                       // +10% за каждый день серии

// Состояние бонуса пользователя на момент now
function getBonusState(user, now = Date.now()) {
  const last = user.lastBonusAt ? new Date(user.lastBonusAt).getTime() : null;
  const available = last === null || now - last >= BONUS_COOLDOWN;

  // Какой станет серия, если забрать бонус сейчас
  const keepsStreak = last !== null && now - last < STREAK_WINDOW;
  const nextStreak = keepsStreak ? (user.bonusStreak || 0) + 1 : 1;

  const base = Math.min(BONUS_BASE + BONUS_PER_LEVEL * (getLevel(user.xp || 0) - 1), BONUS_MAX_BASE);
  const multiplier = 1 + STREAK_STEP * (Math.min(nextStreak, STREAK_MAX) - 1);

  return {
    available,
    nextAt: available ? null : new Date(last + BONUS_COOLDOWN),
    streak: user.bonusStreak || 0,
    nextStreak,
    amount: Math.floor(base * multiplier)
  };
}

module.exports = { getLevelInfo, xpForSpend, addXp, getBonusState, BONUS_XP };