// Скрываем часть email в публичных местах: buyer@test.ru -> bu***@test.ru
function maskEmail(email) {
  const [name, domain] = String(email || '').split('@');
  if (!domain) return '***';
  return `${name.slice(0, 2)}***@${domain}`;
}

module.exports = { maskEmail };