const express = require('express');
const Transaction = require('../models/Transaction');
const { TRANSACTION_TYPES } = require('../models/Transaction');
const { verifyToken, isAdmin } = require('../middleware/auth');

const router = express.Router();

const PAGE_SIZE = 20; // операций на одну "порцию"

// Номер страницы из адреса запроса (?page=2); при мусоре — первая
function getPage(query) {
  const page = parseInt(query.page, 10);
  return Number.isInteger(page) && page > 0 ? page : 1;
}

// Выборка одной страницы операций по фильтру
async function findPage(filter, page, populateUser = false) {
  let query = Transaction.find(filter)
    .sort({ createdAt: -1, _id: -1 }) // сначала новые
    .skip((page - 1) * PAGE_SIZE)
    .limit(PAGE_SIZE);

  if (populateUser) {
    query = query.populate('userId', 'email');
  }

  const [items, total] = await Promise.all([query, Transaction.countDocuments(filter)]);
  return { items, total, hasMore: page * PAGE_SIZE < total };
}

// ---------- GET /api/transactions/my — своя история операций ----------
router.get('/my', verifyToken, async (req, res) => {
  try {
    const page = getPage(req.query);
    const { items, total, hasMore } = await findPage({ userId: req.user.id }, page);

    res.json({
      page,
      total,
      hasMore,
      items: items.map((item) => ({
        id: item._id,
        type: item.type,
        amount: item.amount,
        balanceAfter: item.balanceAfter,
        description: item.description,
        createdAt: item.createdAt
      }))
    });
  } catch (err) {
    console.error('Ошибка загрузки истории:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/transactions/admin — журнал всех операций (только админ) ----------
// Необязательный фильтр по типу: ?type=purchase
router.get('/admin', verifyToken, isAdmin, async (req, res) => {
  try {
    const page = getPage(req.query);

    const filter = {};
    // Тип принимаем только строкой из разрешённого списка
    if (typeof req.query.type === 'string' && TRANSACTION_TYPES.includes(req.query.type)) {
      filter.type = req.query.type;
    }

    const { items, total, hasMore } = await findPage(filter, page, true);

    res.json({
      page,
      total,
      hasMore,
      items: items.map((item) => ({
        id: item._id,
        userEmail: item.userId ? item.userId.email : 'Удалённый пользователь',
        type: item.type,
        amount: item.amount,
        balanceAfter: item.balanceAfter,
        description: item.description,
        createdAt: item.createdAt
      }))
    });
  } catch (err) {
    console.error('Ошибка загрузки журнала:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

module.exports = router;