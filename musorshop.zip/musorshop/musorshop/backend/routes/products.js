const express = require('express');
const mongoose = require('mongoose');
const Product = require('../models/Product');
const User = require('../models/User');
const Purchase = require('../models/Purchase');
const Review = require('../models/Review');
const Wishlist = require('../models/Wishlist');
const { verifyToken, optionalToken, isAdmin } = require('../middleware/auth');
const { logTransaction } = require('../utils/transactions');
const { addXp, xpForSpend } = require('../utils/levels');
const { publishFeed } = require('../utils/feed');
const { notify, notifyRestock } = require('../utils/notify');
const { logAdminAction, pick, diff, AUDIT_FIELDS } = require('../utils/audit');
const { RARITY_KEYS, DEFAULT_RARITY } = require('../config/rarities');
const { CATEGORY_KEYS, WEAR_KEYS, DEFAULT_CATEGORY } = require('../config/productOptions');



const router = express.Router();

// При продаже пользователь получает 80% от цены покупки
const SELL_RATE = 0.8;

// ---------- Вспомогательные функции ----------

// Проверка, что строка похожа на ObjectId (иначе Mongoose выбросит ошибку)
function isValidId(id) {
  return mongoose.isValidObjectId(id);
}

// Проверка и очистка данных товара из тела запроса.
// Возвращает { error } при ошибке или { data } с чистыми данными
function validateProductData(body) {
  const { title, description, price, quantity, imageUrl, rarity, category, wear, statTrak } = body || {};

  if (typeof title !== 'string' || title.trim().length === 0) {
    return { error: 'Введите название товара' };
  }
  if (description !== undefined && typeof description !== 'string') {
    return { error: 'Некорректное описание' };
  }
  if (typeof price !== 'number' || !Number.isFinite(price) || price < 0) {
    return { error: 'Цена должна быть неотрицательным числом' };
  }
  if (typeof quantity !== 'number' || !Number.isInteger(quantity) || quantity < 0) {
    return { error: 'Количество должно быть целым неотрицательным числом' };
  }
  if (imageUrl !== undefined && typeof imageUrl !== 'string') {
    return { error: 'Некорректная ссылка на картинку' };
  }

  // Необязательные характеристики: если переданы — должны быть из справочников
  if (rarity !== undefined && !RARITY_KEYS.includes(rarity)) {
    return { error: 'Некорректная редкость' };
  }
  if (category !== undefined && !CATEGORY_KEYS.includes(category)) {
    return { error: 'Некорректная категория' };
  }
  if (wear !== undefined && wear !== '' && !WEAR_KEYS.includes(wear)) {
    return { error: 'Некорректное качество' };
  }
  if (statTrak !== undefined && typeof statTrak !== 'boolean') {
    return { error: 'Некорректное значение StatTrak' };
  }

  const cleanUrl = (imageUrl || '').trim();
  // Разрешаем только обычные веб-ссылки (или пустое значение)
  if (cleanUrl && !/^https?:\/\//i.test(cleanUrl)) {
    return { error: 'Ссылка на картинку должна начинаться с http:// или https://' };
  }

  return {
    data: {
      title: title.trim(),
      description: (description || '').trim(),
      price,
      quantity,
      imageUrl: cleanUrl,
      rarity: rarity || DEFAULT_RARITY,
      category: category || DEFAULT_CATEGORY,
      wear: wear || '',
      statTrak: Boolean(statTrak)
    }
  };
}

// ==================== КАТАЛОГ ====================

const CATALOG_PAGE_SIZE = 8; // товаров на странице

// Варианты сортировки. _id в конце делает порядок однозначным:
// без него товары с одинаковой ценой могли бы "прыгать" между страницами
const CATALOG_SORTS = {
  'newest':        { createdAt: -1, _id: -1 },
  'price-asc':     { price: 1, _id: 1 },
  'price-desc':    { price: -1, _id: 1 },
  'title-asc':     { title: 1, _id: 1 },
  'title-desc':    { title: -1, _id: 1 },
  'quantity-desc': { quantity: -1, _id: 1 }
};

// Параметр из адреса запроса как строка. Всё, что не строка (например, объект
// из ?category[$ne]=x), превращается в пустую строку — так отсекаются NoSQL-инъекции
function queryString(value) {
  return typeof value === 'string' ? value.trim() : '';
}

// Экранирование спецсимволов регулярных выражений в поисковой строке
function escapeRegex(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// ---------- GET /api/products — страница каталога (доступно всем) ----------
// Параметры: page, sort, search, category, rarity, wear, minPrice, maxPrice,
//            inStock=1, statTrak=1, wishlist=1
router.get('/', optionalToken, async (req, res) => {
  try {
    const query = req.query;
    const filter = {};

    // Поиск по названию и описанию без учёта регистра
    const search = queryString(query.search).slice(0, 100);
    if (search) {
      const regex = new RegExp(escapeRegex(search), 'i');
      filter.$or = [{ title: regex }, { description: regex }];
    }

    // Характеристики: принимаем только значения из справочников
    const category = queryString(query.category);
    if (CATEGORY_KEYS.includes(category)) filter.category = category;

    const rarity = queryString(query.rarity);
    if (RARITY_KEYS.includes(rarity)) filter.rarity = rarity;

    const wear = queryString(query.wear);
    if (WEAR_KEYS.includes(wear)) filter.wear = wear;

    if (queryString(query.statTrak) === '1') filter.statTrak = true;
    if (queryString(query.inStock) === '1') filter.quantity = { $gt: 0 };

    // Диапазон цены: только целые неотрицательные числа
    const minPrice = queryString(query.minPrice);
    const maxPrice = queryString(query.maxPrice);
    if (/^\d{1,12}$/.test(minPrice) || /^\d{1,12}$/.test(maxPrice)) {
      filter.price = {};
      if (/^\d{1,12}$/.test(minPrice)) filter.price.$gte = Number(minPrice);
      if (/^\d{1,12}$/.test(maxPrice)) filter.price.$lte = Number(maxPrice);
    }

    // Только избранное: работает для вошедшего пользователя, гостю вернётся пустой список
    if (queryString(query.wishlist) === '1') {
      const wished = req.user
        ? await Wishlist.find({ userId: req.user.id }).select('productId')
        : [];
      filter._id = { $in: wished.map((item) => item.productId) };
    }

    const sort = CATALOG_SORTS[queryString(query.sort)] || CATALOG_SORTS.newest;

    // Сначала считаем, сколько товаров подходит, затем выбираем нужную страницу
    const total = await Product.countDocuments(filter);
    const pages = Math.max(1, Math.ceil(total / CATALOG_PAGE_SIZE));

    // Номер страницы держим в допустимых пределах
    const requested = parseInt(queryString(query.page), 10);
    const page = Math.min(Math.max(1, Number.isInteger(requested) ? requested : 1), pages);

    const items = await Product.find(filter)
      .sort(sort)
      .collation({ locale: 'ru', strength: 2 }) // сортировка названий без учёта регистра
      .skip((page - 1) * CATALOG_PAGE_SIZE)
      .limit(CATALOG_PAGE_SIZE);

    res.json({ items, total, page, pages, pageSize: CATALOG_PAGE_SIZE });
  } catch (err) {
    console.error('Ошибка загрузки товаров:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/products/by-ids — товары по списку id (нужно корзине) ----------
// Пример: /api/products/by-ids?ids=id1,id2,id3
router.get('/by-ids', async (req, res) => {
  try {
    const ids = queryString(req.query.ids)
      .split(',')
      .filter((id) => isValidId(id))
      .slice(0, 50);

    const items = ids.length > 0 ? await Product.find({ _id: { $in: ids } }) : [];
    res.json(items);
  } catch (err) {
    console.error('Ошибка загрузки товаров по id:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/products/brief — краткий список всех товаров (только админ) ----------
// Нужен форме кейса, где выбираются предметы
router.get('/brief', verifyToken, isAdmin, async (req, res) => {
  try {
    const items = await Product.find()
      .select('title price rarity')
      .sort({ price: 1 })
      .limit(1000);
    res.json(items);
  } catch (err) {
    console.error('Ошибка загрузки списка товаров:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/products/my-purchases — история покупок ----------
// ВАЖНО: маршруты с фиксированным путём стоят ВЫШЕ маршрутов с /:id,
// иначе Express примет "my-purchases" за id товара
router.get('/my-purchases', verifyToken, async (req, res) => {
  try {
    const purchases = await Purchase.find({ userId: req.user.id })
      .sort({ purchasedAt: -1 });
    res.json(purchases);
  } catch (err) {
    console.error('Ошибка загрузки покупок:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/products/sell/:purchaseId — продать за 80% ----------
router.post('/sell/:purchaseId', verifyToken, async (req, res) => {
  try {
    const { purchaseId } = req.params;
    if (!isValidId(purchaseId)) {
      return res.status(400).json({ message: 'Некорректный идентификатор покупки' });
    }

    // Одной операцией ищем АКТИВНУЮ покупку ЭТОГО пользователя и помечаем проданной.
    // Если покупка чужая или уже продана — вернётся null.
    // Это защищает от двойной продажи при быстрых повторных кликах
    const purchase = await Purchase.findOneAndUpdate(
      { _id: purchaseId, userId: req.user.id, status: 'active' },
      { status: 'sold', soldAt: new Date() },
      { returnDocument: 'after' }
    );

    if (!purchase) {
      return res.status(400).json({ message: 'Покупка не найдена или уже продана' });
    }

    // Сумма возврата: 80% от цены покупки, округление вниз
    const refund = Math.floor(purchase.price * SELL_RATE);

    // Возвращаем деньги на баланс
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { $inc: { balance: refund } },
      { returnDocument: 'after' }
    );

    // Возвращаем товар на витрину (если админ его удалил — ничего не произойдёт)
    const restocked = await Product.findOneAndUpdate(
      { _id: purchase.productId },
      { $inc: { quantity: 1 } },
      { returnDocument: 'after' }
    );
    // Остаток стал равен 1 — значит, товара не было в наличии, а теперь он появился
    if (restocked && restocked.quantity === 1) {
      await notifyRestock(restocked, req.user.id);
    }
    
    if (user) {
      await logTransaction({
        userId: user._id,
        type: 'sale',
        amount: refund,
        balanceAfter: user.balance,
        description: purchase.productTitle
      });
    }

    res.json({
      message: `Товар продан за ${refund.toLocaleString('ru-RU')} ₽`,
      refund,
      balance: user ? user.balance : 0
    });
  } catch (err) {
    console.error('Ошибка продажи:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ==================== КОРЗИНА ====================

const MAX_CART_LINES = 20;     // максимум разных товаров в одном заказе
const MAX_CART_QUANTITY = 10;  // максимум штук одного товара

// ---------- POST /api/products/cart/checkout — оплатить корзину ----------
// Тело запроса: { items: [{ productId, quantity }, ...] }
router.post('/cart/checkout', verifyToken, async (req, res) => {
  // Список уже зарезервированных позиций — чтобы вернуть их на склад при неудаче
  const reserved = [];
  const rollbackStock = async () => {
    for (const item of reserved) {
      await Product.updateOne({ _id: item.productId }, { $inc: { quantity: item.quantity } });
    }
    reserved.length = 0; // повторный вызов ничего не вернёт дважды
  };

  try {
    if (req.user.role === 'admin') {
      return res.status(403).json({ message: 'Администратор не может покупать товары' });
    }

    const { items } = req.body || {};

    // ---------- Проверка состава корзины ----------
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ message: 'Корзина пуста' });
    }
    if (items.length > MAX_CART_LINES) {
      return res.status(400).json({ message: `В заказе может быть не больше ${MAX_CART_LINES} разных товаров` });
    }

    const seen = new Set();
    for (const item of items) {
      const valid = item &&
        typeof item.productId === 'string' && isValidId(item.productId) &&
        Number.isInteger(item.quantity) &&
        item.quantity >= 1 && item.quantity <= MAX_CART_QUANTITY;

      if (!valid || seen.has(item.productId)) {
        return res.status(400).json({ message: 'Некорректный состав корзины' });
      }
      seen.add(item.productId);
    }

    // ---------- Шаг 1. Резервируем товары на складе ----------
    // Каждую позицию списываем одной операцией с условием "остатка хватает"
    const lines = [];
    for (const item of items) {
      const product = await Product.findOneAndUpdate(
        { _id: item.productId, quantity: { $gte: item.quantity } },
        { $inc: { quantity: -item.quantity } },
        { returnDocument: 'after' }
      );

      if (!product) {
        await rollbackStock();
        const existing = await Product.findById(item.productId).select('title quantity');
        return res.status(existing ? 400 : 404).json({
          message: existing
            ? `«${existing.title}»: в наличии только ${existing.quantity} шт.`
            : 'Один из товаров в корзине больше не продаётся'
        });
      }

      reserved.push({ productId: item.productId, quantity: item.quantity });
      lines.push({ product, quantity: item.quantity });
    }

    // ---------- Шаг 2. Списываем общую сумму ----------
    const total = lines.reduce((sum, line) => sum + line.product.price * line.quantity, 0);

    const user = await User.findOneAndUpdate(
      { _id: req.user.id, balance: { $gte: total } },
      { $inc: { balance: -total } },
      { returnDocument: 'after' }
    );

    if (!user) {
      await rollbackStock();
      return res.status(400).json({ message: 'Недостаточно средств на балансе' });
    }

    // ---------- Шаг 3. Создаём записи о покупках (по одной на каждую штуку) ----------
    const purchaseDocs = [];
    lines.forEach((line) => {
      for (let i = 0; i < line.quantity; i++) {
        purchaseDocs.push({
          userId: user._id,
          productId: line.product._id,
          productTitle: line.product.title,
          productImage: line.product.imageUrl,
          price: line.product.price
        });
      }
    });

    try {
      await Purchase.insertMany(purchaseDocs);
    } catch (createErr) {
      // Записи не создались — возвращаем и товары, и деньги
      await rollbackStock();
      await User.updateOne({ _id: user._id }, { $inc: { balance: total } });
      throw createErr;
    }

    // ---------- Шаг 4. История операций: по строке на каждую позицию ----------
    let runningBalance = user.balance + total; // баланс до покупки
    for (const line of lines) {
      const lineTotal = line.product.price * line.quantity;
      runningBalance -= lineTotal;
      await logTransaction({
        userId: user._id,
        type: 'purchase',
        amount: -lineTotal,
        balanceAfter: runningBalance,
        description: line.quantity > 1 ? `${line.product.title} × ${line.quantity}` : line.product.title
      });
    }
    await addXp(user._id, xpForSpend(total));
    // В ленту попадает каждая позиция заказа
    lines.forEach((line) => publishFeed({
      user,
      title: line.product.title,
      rarity: line.product.rarity,
      price: line.product.price,
      source: 'shop'
    }));
    res.json({
      message: `Куплено предметов: ${purchaseDocs.length}`,
      count: purchaseDocs.length,
      total,
      balance: user.balance
    });
  } catch (err) {
    // При непредвиденной ошибке на этапе резервирования возвращаем товары на склад
    await rollbackStock().catch(() => {});
    console.error('Ошибка оформления корзины:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ==================== ИЗБРАННОЕ ====================

// ---------- GET /api/products/wishlist-ids — id товаров в избранном ----------
// Лёгкий запрос: нужен, чтобы закрасить сердечки на карточках
router.get('/wishlist-ids', verifyToken, async (req, res) => {
  try {
    const items = await Wishlist.find({ userId: req.user.id }).select('productId');
    res.json(items.map((item) => item.productId.toString()));
  } catch (err) {
    console.error('Ошибка загрузки избранного:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/products/my-wishlist — избранное с данными товаров ----------
router.get('/my-wishlist', verifyToken, async (req, res) => {
  try {
    const items = await Wishlist.find({ userId: req.user.id })
      .populate('productId') // подставляем вместо id сам товар
      .sort({ addedAt: -1 });

    // Если товар удалён админом, populate вернёт null — такие записи пропускаем
    const result = items
      .filter((item) => item.productId)
      .map((item) => ({
        _id: item.productId._id,
        title: item.productId.title,
        price: item.productId.price,
        quantity: item.productId.quantity,
        imageUrl: item.productId.imageUrl,
        addedAt: item.addedAt
      }));

    res.json(result);
  } catch (err) {
    console.error('Ошибка загрузки избранного:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/products/wishlist/:productId — добавить в избранное ----------
router.post('/wishlist/:productId', verifyToken, async (req, res) => {
  try {
    const { productId } = req.params;
    if (!isValidId(productId)) {
      return res.status(400).json({ message: 'Некорректный идентификатор товара' });
    }

    const exists = await Product.exists({ _id: productId });
    if (!exists) {
      return res.status(404).json({ message: 'Товар не найден' });
    }

    // upsert: создаёт запись, только если её ещё нет.
    // Повторное добавление не вызывает ошибку и не создаёт дубль
    await Wishlist.updateOne(
      { userId: req.user.id, productId },
      { $setOnInsert: { addedAt: new Date() } },
      { upsert: true }
    );

    res.json({ message: 'Добавлено в избранное' });
  } catch (err) {
    console.error('Ошибка добавления в избранное:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- DELETE /api/products/wishlist/:productId — убрать из избранного ----------
router.delete('/wishlist/:productId', verifyToken, async (req, res) => {
  try {
    const { productId } = req.params;
    if (!isValidId(productId)) {
      return res.status(400).json({ message: 'Некорректный идентификатор товара' });
    }

    // Удаляем только СВОЮ запись — userId берётся из токена, а не из запроса
    await Wishlist.deleteOne({ userId: req.user.id, productId });
    res.json({ message: 'Удалено из избранного' });
  } catch (err) {
    console.error('Ошибка удаления из избранного:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ==================== АДМИН: СТАТИСТИКА ====================

// Товар считается "заканчивающимся", если его осталось не больше этого числа
const LOW_STOCK_LIMIT = 3;
// Чистая выручка с одной покупки: цена минус возврат покупателю,
// если предмет был продан обратно (возврат = 80% цены, округление вниз)
// Сколько заплатил пользователь: paid, а если его нет (старые записи) — price
const USER_PAID = { $ifNull: ['$paid', '$price'] };

// Сколько получил магазин. Для покупок на площадке это только комиссия (shopIncome),
// для остальных — вся заплаченная сумма
const PAID = { $ifNull: ['$shopIncome', USER_PAID] };

const NET_REVENUE = {
  $subtract: [
    PAID,
    {
      $cond: [
        { $eq: ['$status', 'sold'] },
        { $floor: { $multiply: ['$price', SELL_RATE] } },
        0
      ]
    }
  ]
};

// ---------- GET /api/products/admin/stats — сводная статистика ----------
router.get('/admin/stats', verifyToken, isAdmin, async (req, res) => {
  try {
      // Чистая выручка (с учётом возвратов) и количество покупок
    const [totals] = await Purchase.aggregate([
      { $group: { _id: null, revenue: { $sum: NET_REVENUE }, count: { $sum: 1 } } }
    ]);

    // Топ-5 покупателей по потраченной сумме
    const topBuyers = await Purchase.aggregate([
      // группируем покупки по пользователю
      { $group: { _id: '$userId', totalSpent: { $sum: USER_PAID }, purchasesCount: { $sum: 1 } } },
      { $sort: { totalSpent: -1 } },
      { $limit: 5 },
      // подтягиваем email из коллекции users
      { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'user' } },
      {
        $project: {
          _id: 0,
          email: { $ifNull: [{ $arrayElemAt: ['$user.email', 0] }, 'Удалённый пользователь'] },
          totalSpent: 1,
          purchasesCount: 1
        }
      }
    ]);

    // Топ-5 товаров по количеству продаж
    const topProducts = await Purchase.aggregate([
      {
        $group: {
          _id: '$productId',
          title: { $first: '$productTitle' },
          salesCount: { $sum: 1 },
          revenue: { $sum: '$price' }
        }
      },
      { $sort: { salesCount: -1, revenue: -1 } },
      { $limit: 5 },
      { $project: { _id: 0, title: 1, salesCount: 1, revenue: 1 } }
    ]);

    // Заканчивающиеся товары
    const lowStock = await Product.find({ quantity: { $lte: LOW_STOCK_LIMIT } })
      .sort({ quantity: 1 })
      .limit(10)
      .select('title quantity');

    const totalUsers = await User.countDocuments({ role: 'user' });
    const totalProducts = await Product.countDocuments();

    res.json({
      totalRevenue: totals ? totals.revenue : 0,
      totalSales: totals ? totals.count : 0,
      totalUsers,
      totalProducts,
      topBuyers,
      topProducts,
      lowStock
    });
  } catch (err) {
    console.error('Ошибка статистики:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/products/admin/purchases — все покупки (для CSV) ----------
router.get('/admin/purchases', verifyToken, isAdmin, async (req, res) => {
  try {
    const purchases = await Purchase.find()
      .populate('userId', 'email') // вместо id пользователя подставляем его email
      .sort({ purchasedAt: -1 });

    res.json(purchases.map((purchase) => ({
      id: purchase._id,
      userEmail: purchase.userId ? purchase.userId.email : 'Удалённый пользователь',
      productTitle: purchase.productTitle,
      price: purchase.price,
      status: purchase.status,
      purchasedAt: purchase.purchasedAt,
      soldAt: purchase.soldAt || null
    })));
  } catch (err) {
    console.error('Ошибка выгрузки покупок:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/products/admin/chart-data — продажи по дням за 30 дней ----------
// Для каждого дня возвращает: revenue — оборот, profit — чистая прибыль, count — число покупок
router.get('/admin/chart-data', verifyToken, isAdmin, async (req, res) => {
  try {
    const DAYS = 30;
    // Часовой пояс сервера — чтобы операции группировались по местным суткам
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

    // Начало периода: полночь 29 дней назад (вместе с сегодняшним днём — 30 дней)
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - (DAYS - 1));

    // Выражение "дата в формате ГГГГ-ММ-ДД" для группировки по дням
    const dayKey = (field) => ({
      $dateToString: { format: '%Y-%m-%d', date: field, timezone }
    });

    // Покупки по дням: оборот и количество
    const sales = await Purchase.aggregate([
      { $match: { purchasedAt: { $gte: start } } },
      { $group: { _id: dayKey('$purchasedAt'), revenue: { $sum: PAID }, count: { $sum: 1 } } }
    ]);

    // Возвраты по дням: сколько денег вернули покупателям за обратную продажу.
    // Группируем по дате продажи (soldAt), а не покупки
    const refunds = await Purchase.aggregate([
      { $match: { status: 'sold', soldAt: { $gte: start } } },
      {
        $group: {
          _id: dayKey('$soldAt'),
          refunded: { $sum: { $floor: { $multiply: ['$price', SELL_RATE] } } }
        }
      }
    ]);

    const salesByDate = new Map(sales.map((row) => [row._id, row]));
    const refundsByDate = new Map(refunds.map((row) => [row._id, row.refunded]));

    // Собираем все 30 дней подряд; дни без операций заполняем нулями
    const result = [];
    for (let i = 0; i < DAYS; i++) {
      const day = new Date(start);
      day.setDate(start.getDate() + i);

      const key = [
        day.getFullYear(),
        String(day.getMonth() + 1).padStart(2, '0'),
        String(day.getDate()).padStart(2, '0')
      ].join('-');

      const sale = salesByDate.get(key);
      const revenue = sale ? sale.revenue : 0;
      const refunded = refundsByDate.get(key) || 0;

      result.push({
        date: key,
        revenue,                     // оборот за день
        profit: revenue - refunded,  // чистая прибыль за день (может быть отрицательной)
        count: sale ? sale.count : 0
      });
    }

    res.json(result);
  } catch (err) {
    console.error('Ошибка данных графика:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/products — добавить товар (только админ) ----------
router.post('/', verifyToken, isAdmin, async (req, res) => {
  try {
    const { error, data } = validateProductData(req.body);
    if (error) {
      return res.status(400).json({ message: error });
    }

    const product = await Product.create(data);
    await logAdminAction(req, 'product.create', `«${product.title}»`, {
      snapshot: pick(product, AUDIT_FIELDS.product)
    });
    res.status(201).json(product);
  } catch (err) {
    console.error('Ошибка добавления товара:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- PUT /api/products/:id — редактировать товар (только админ) ----------
router.put('/:id', verifyToken, isAdmin, async (req, res) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор товара' });
    }

    const { error, data } = validateProductData(req.body);
    if (error) {
      return res.status(400).json({ message: error });
    }

    // Запоминаем прежнее состояние товара: для журнала действий (что изменилось)
    // и чтобы понять, появился ли товар в наличии
    const previous = await Product.findById(req.params.id);

    const product = await Product.findByIdAndUpdate(req.params.id, data, {
      returnDocument: 'after',           // вернуть уже обновлённый документ
      runValidators: true  // применить проверки из схемы
    });

    if (!product) {
      return res.status(404).json({ message: 'Товар не найден' });
    }
    if (previous && previous.quantity === 0 && product.quantity > 0) {
      await notifyRestock(product);
    }
    await logAdminAction(req, 'product.update', `«${product.title}»`, {
      changes: previous ? diff(previous, product, AUDIT_FIELDS.product) : []
    });
    res.json(product);
  } catch (err) {
    console.error('Ошибка редактирования товара:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- DELETE /api/products/:id — удалить товар (только админ) ----------
router.delete('/:id', verifyToken, isAdmin, async (req, res) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор товара' });
    }

    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'Товар не найден' });
    }
    await logAdminAction(req, 'product.delete', `«${product.title}»`, {
      snapshot: pick(product, AUDIT_FIELDS.product)
    });
    res.json({ message: 'Товар удалён' });
  } catch (err) {
    console.error('Ошибка удаления товара:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/products/:id/buy — купить товар ----------
router.post('/:id/buy', verifyToken, async (req, res) => {
  try {
    // Админ управляет магазином, но сам не покупает
    if (req.user.role === 'admin') {
      return res.status(403).json({ message: 'Администратор не может покупать товары' });
    }

    const productId = req.params.id;
    if (!isValidId(productId)) {
      return res.status(400).json({ message: 'Некорректный идентификатор товара' });
    }

    // Шаг 1. Забираем одну штуку со склада — только если остаток >= 1.
    // Условие и уменьшение выполняются одной операцией, поэтому два покупателя
    // не смогут одновременно купить последний экземпляр
    const product = await Product.findOneAndUpdate(
      { _id: productId, quantity: { $gte: 1 } },
      { $inc: { quantity: -1 } },
      { returnDocument: 'after' }
    );

    if (!product) {
      // Выясняем причину: товара нет вообще или он закончился
      const exists = await Product.exists({ _id: productId });
      return res.status(exists ? 400 : 404).json({
        message: exists ? 'Товар закончился' : 'Товар не найден'
      });
    }

    // Шаг 2. Списываем деньги — только если баланса хватает
    const user = await User.findOneAndUpdate(
      { _id: req.user.id, balance: { $gte: product.price } },
      { $inc: { balance: -product.price } },
      { returnDocument: 'after' }
    );

    if (!user) {
      // Денег не хватило — возвращаем товар на склад
      await Product.updateOne({ _id: productId }, { $inc: { quantity: 1 } });
      return res.status(400).json({ message: 'Недостаточно средств на балансе' });
    }

    // Шаг 3. Создаём запись о покупке
    let purchase;
    try {
      purchase = await Purchase.create({
        userId: user._id,
        productId: product._id,
        productTitle: product.title,
        productImage: product.imageUrl,
        price: product.price
      });
    } catch (createErr) {
      // Запись не создалась — откатываем и склад, и деньги
      await Product.updateOne({ _id: productId }, { $inc: { quantity: 1 } });
      await User.updateOne({ _id: user._id }, { $inc: { balance: product.price } });
      throw createErr;
    }

    await logTransaction({
      userId: user._id,
      type: 'purchase',
      amount: -product.price,
      balanceAfter: user.balance,
      description: product.title
    });
    await addXp(user._id, xpForSpend(product.price));
    publishFeed({ user, title: product.title, rarity: product.rarity, price: product.price, source: 'shop' });
    res.json({
      message: `Вы купили «${product.title}»`,
      balance: user.balance,
      purchase
    });
  } catch (err) {
    console.error('Ошибка покупки:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ==================== ОТЗЫВЫ И РЕЙТИНГИ ====================

// Скрываем часть email в публичных отзывах: buyer@test.ru -> bu***@test.ru
function maskEmail(email) {
  const [name, domain] = String(email).split('@');
  if (!domain) return '***';
  return `${name.slice(0, 2)}***@${domain}`;
}

// ---------- GET /api/products/ratings/all — средние рейтинги всех товаров ----------
router.get('/ratings/all', async (req, res) => {
  try {
    const rows = await Review.aggregate([
      { $group: { _id: '$productId', average: { $avg: '$rating' }, count: { $sum: 1 } } }
    ]);

    // Превращаем в объект { idТовара: { average, count } }, среднее — до 1 знака
    const result = {};
    rows.forEach((row) => {
      result[row._id.toString()] = {
        average: Math.round(row.average * 10) / 10,
        count: row.count
      };
    });

    res.json(result);
  } catch (err) {
    console.error('Ошибка загрузки рейтингов:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/products/:id/reviews — отзывы товара (доступно всем) ----------
router.get('/:id/reviews', async (req, res) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор товара' });
    }

    const reviews = await Review.find({ productId: req.params.id }).sort({ createdAt: -1 });
    
    // Кто из авторов отзывов действительно получал этот предмет (покупка или кейс)
    const buyerIds = await Purchase.distinct('userId', {
      productId: req.params.id,
      userId: { $in: reviews.map((review) => review.userId) }
    });
    const verifiedBuyers = new Set(buyerIds.map(String));

    const count = reviews.length;
    const sum = reviews.reduce((total, review) => total + review.rating, 0);
    const average = count > 0 ? Math.round((sum / count) * 10) / 10 : 0;

    res.json({
      average,
      count,
      reviews: reviews.map((review) => ({
        id: review._id,
        userId: review.userId,
        userEmail: maskEmail(review.userEmail), // полный email наружу не отдаём
        rating: review.rating,
        comment: review.comment,
        createdAt: review.createdAt,
        editedAt: review.editedAt || null,
        editedByAdmin: Boolean(review.editedByAdmin),
        verified: verifiedBuyers.has(String(review.userId))
      }))
    });
  } catch (err) {
    console.error('Ошибка загрузки отзывов:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/products/:id/can-review — может ли пользователь оставить отзыв ----------
router.get('/:id/can-review', verifyToken, async (req, res) => {
  try {
    const productId = req.params.id;
    if (!isValidId(productId)) {
      return res.status(400).json({ message: 'Некорректный идентификатор товара' });
    }

    const [purchased, alreadyReviewed] = await Promise.all([
      Purchase.exists({ userId: req.user.id, productId }),
      Review.exists({ userId: req.user.id, productId })
    ]);

    res.json({
      purchased: Boolean(purchased),
      alreadyReviewed: Boolean(alreadyReviewed),
      canReview: req.user.role === 'user' && Boolean(purchased) && !alreadyReviewed
    });
  } catch (err) {
    console.error('Ошибка проверки права на отзыв:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/products/:id/review — оставить отзыв ----------
router.post('/:id/review', verifyToken, async (req, res) => {
  try {
    // Админ не оценивает собственные товары
    if (req.user.role === 'admin') {
      return res.status(403).json({ message: 'Администратор не может оставлять отзывы' });
    }

    const productId = req.params.id;
    if (!isValidId(productId)) {
      return res.status(400).json({ message: 'Некорректный идентификатор товара' });
    }

    const { rating, comment } = req.body || {};

    if (typeof rating !== 'number' || !Number.isInteger(rating) || rating < 1 || rating > 5) {
      return res.status(400).json({ message: 'Оценка должна быть целым числом от 1 до 5' });
    }
    if (comment !== undefined && typeof comment !== 'string') {
      return res.status(400).json({ message: 'Некорректный комментарий' });
    }

    const cleanComment = (comment || '').trim();
    if (cleanComment.length > 500) {
      return res.status(400).json({ message: 'Комментарий не должен превышать 500 символов' });
    }

    const productExists = await Product.exists({ _id: productId });
    if (!productExists) {
      return res.status(404).json({ message: 'Товар не найден' });
    }
    
    // Отзыв может оставить только тот, у кого этот предмет есть в истории покупок
    const hasPurchase = await Purchase.exists({ userId: req.user.id, productId });
    if (!hasPurchase) {
      return res.status(403).json({ message: 'Отзыв могут оставить только покупатели этого товара' });
    }

    const user = await User.findById(req.user.id).select('email');
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    await Review.create({
      userId: user._id,
      productId,
      userEmail: user.email,
      rating,
      comment: cleanComment
    });

    res.status(201).json({ message: 'Спасибо за отзыв!' });
  } catch (err) {
    // Сработал уникальный индекс — отзыв от этого пользователя уже есть
    if (err.code === 11000) {
      return res.status(400).json({ message: 'Вы уже оставляли отзыв на этот товар' });
    }
    console.error('Ошибка создания отзыва:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- PUT /api/products/reviews/:reviewId — изменить отзыв ----------
// Доступно автору отзыва и администратору
router.put('/reviews/:reviewId', verifyToken, async (req, res) => {
  try {
    const { reviewId } = req.params;
    if (!isValidId(reviewId)) {
      return res.status(400).json({ message: 'Некорректный идентификатор отзыва' });
    }

    const { rating, comment } = req.body || {};

    if (typeof rating !== 'number' || !Number.isInteger(rating) || rating < 1 || rating > 5) {
      return res.status(400).json({ message: 'Оценка должна быть целым числом от 1 до 5' });
    }
    if (comment !== undefined && typeof comment !== 'string') {
      return res.status(400).json({ message: 'Некорректный комментарий' });
    }

    const cleanComment = (comment || '').trim();
    if (cleanComment.length > 500) {
      return res.status(400).json({ message: 'Комментарий не должен превышать 500 символов' });
    }

    const review = await Review.findById(reviewId);
    if (!review) {
      return res.status(404).json({ message: 'Отзыв не найден' });
    }

    // Проверка прав: менять отзыв может только его автор или админ
    const isOwner = review.userId.toString() === String(req.user.id);
    const isAdminUser = req.user.role === 'admin';
    if (!isOwner && !isAdminUser) {
      return res.status(403).json({ message: 'Нельзя изменять чужой отзыв' });
    }

    // Запоминаем отзыв до изменения — для журнала действий
    const reviewBefore = { rating: review.rating, comment: review.comment };
    review.rating = rating;
    review.comment = cleanComment;
    review.editedAt = new Date();
    review.editedByAdmin = isAdminUser && !isOwner;
    await review.save();
    // Отзыв изменил администратор — сообщаем автору
    if (review.editedByAdmin) {
      const reviewed = await Product.findById(review.productId).select('title');
      await notify(review.userId, 'review',
        `Администратор изменил ваш отзыв о товаре «${reviewed ? reviewed.title : 'удалённый товар'}»`);
      await logAdminAction(req, 'review.edit',
        `${review.userEmail} о товаре «${reviewed ? reviewed.title : 'удалённый товар'}»`,
        { changes: diff(reviewBefore, review, ['rating', 'comment']) });
    }

    res.json({ message: 'Отзыв обновлён' });
  } catch (err) {
    console.error('Ошибка изменения отзыва:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- DELETE /api/products/reviews/:reviewId — удалить отзыв ----------
// Доступно автору отзыва и администратору
router.delete('/reviews/:reviewId', verifyToken, async (req, res) => {
  try {
    const { reviewId } = req.params;
    if (!isValidId(reviewId)) {
      return res.status(400).json({ message: 'Некорректный идентификатор отзыва' });
    }

    const review = await Review.findById(reviewId);
    if (!review) {
      return res.status(404).json({ message: 'Отзыв не найден' });
    }

    const isOwner = review.userId.toString() === String(req.user.id);
    if (!isOwner && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Нельзя удалять чужой отзыв' });
    }

    await review.deleteOne();
    // Отзыв удалил администратор — сообщаем автору
    if (!isOwner) {
      const reviewed = await Product.findById(review.productId).select('title');
      await notify(review.userId, 'review',
        `Администратор удалил ваш отзыв о товаре «${reviewed ? reviewed.title : 'удалённый товар'}»`);
      await logAdminAction(req, 'review.delete',
        `${review.userEmail} о товаре «${reviewed ? reviewed.title : 'удалённый товар'}»`,
        { snapshot: pick(review, ['rating', 'comment']) });
    }

    res.json({ message: 'Отзыв удалён' });
  } catch (err) {
    console.error('Ошибка удаления отзыва:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

module.exports = router;