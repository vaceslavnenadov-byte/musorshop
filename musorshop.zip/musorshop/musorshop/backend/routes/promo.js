const express = require('express');
const mongoose = require('mongoose');
const PromoCode = require('../models/PromoCode');
const User = require('../models/User');
const { verifyToken, isAdmin } = require('../middleware/auth');
const { logTransaction } = require('../utils/transactions');
const { logAdminAction, pick, diff, AUDIT_FIELDS } = require('../utils/audit');
const router = express.Router();

// Код: от 3 до 20 символов — латинские буквы, цифры, дефис и подчёркивание
const CODE_REGEX = /^[A-Z0-9_-]{3,20}$/;
const MAX_BONUS = 1000000;      // максимум для фиксированного бонуса, ₽
const MAX_PERCENT = 100;        // максимум для процентного бонуса, %
const MAX_USES_LIMIT = 100000;  // максимум лимита активаций
const MAX_DEPOSIT = 1000000;    // максимум одного пополнения (как в /auth/deposit)

// Проверка и очистка данных промокода (используется при создании и изменении).
// Возвращает { error } при ошибке или { data } с чистыми данными
function validatePromoData(body) {
  const { code, type = 'fixed', amount, maxUses } = body || {};

  if (typeof code !== 'string' || !CODE_REGEX.test(code.trim().toUpperCase())) {
    return { error: 'Код: от 3 до 20 символов, латинские буквы, цифры, дефис и подчёркивание' };
  }
  if (type !== 'fixed' && type !== 'percent') {
    return { error: 'Некорректный тип промокода' };
  }
  if (typeof amount !== 'number' || !Number.isInteger(amount) || amount < 1) {
    return { error: 'Размер бонуса должен быть целым положительным числом' };
  }
  if (type === 'fixed' && amount > MAX_BONUS) {
    return { error: `Бонус не может превышать ${MAX_BONUS.toLocaleString('ru-RU')} ₽` };
  }
  if (type === 'percent' && amount > MAX_PERCENT) {
    return { error: `Процент не может превышать ${MAX_PERCENT}` };
  }
  if (typeof maxUses !== 'number' || !Number.isInteger(maxUses) || maxUses < 1 || maxUses > MAX_USES_LIMIT) {
    return { error: `Лимит активаций должен быть целым числом от 1 до ${MAX_USES_LIMIT.toLocaleString('ru-RU')}` };
  }

  return { data: { code: code.trim().toUpperCase(), type, amount, maxUses } };
}

// ---------- POST /api/promo/redeem — активировать промокод ----------
// Тело запроса: { code, depositAmount? }
// depositAmount нужен только для процентных промокодов
router.post('/redeem', verifyToken, async (req, res) => {
  try {
    if (req.user.role === 'admin') {
      return res.status(403).json({ message: 'Администратор не может активировать промокоды' });
    }

    const { code, depositAmount } = req.body || {};
    if (typeof code !== 'string') {
      return res.status(400).json({ message: 'Введите промокод' });
    }

    const cleanCode = code.trim().toUpperCase();
    if (!CODE_REGEX.test(cleanCode)) {
      return res.status(404).json({ message: 'Промокод не найден' });
    }

    // Если сумма пополнения передана — она должна быть корректной
    const hasDeposit = depositAmount !== undefined && depositAmount !== null;
    if (hasDeposit) {
      if (typeof depositAmount !== 'number' || !Number.isInteger(depositAmount) || depositAmount <= 0) {
        return res.status(400).json({ message: 'Введите корректную сумму пополнения' });
      }
      if (depositAmount > MAX_DEPOSIT) {
        return res.status(400).json({
          message: `Максимальная сумма пополнения — ${MAX_DEPOSIT.toLocaleString('ru-RU')} ₽`
        });
      }
    }

    // Одной операцией проверяем три условия и записываем активацию:
    // код существует, этот пользователь его ещё не применял, лимит не исчерпан.
    // Благодаря этому код нельзя применить дважды даже одновременными запросами
    const promo = await PromoCode.findOneAndUpdate(
      {
        code: cleanCode,
        usedBy: { $ne: req.user.id },
        $expr: { $lt: [{ $size: '$usedBy' }, '$maxUses'] }
      },
      { $addToSet: { usedBy: req.user.id } },
      { returnDocument: 'after' }
    );

    if (!promo) {
      // Выясняем причину, чтобы показать понятное сообщение
      const existing = await PromoCode.findOne({ code: cleanCode });
      if (!existing) {
        return res.status(404).json({ message: 'Промокод не найден' });
      }
      const alreadyUsed = existing.usedBy.some((id) => id.toString() === String(req.user.id));
      return res.status(400).json({
        message: alreadyUsed ? 'Вы уже активировали этот промокод' : 'Промокод больше не действует'
      });
    }

    // Отмена активации — на случай, если дальше что-то пойдёт не так
    const cancelActivation = () =>
      PromoCode.updateOne({ _id: promo._id }, { $pull: { usedBy: req.user.id } });

    const isPercent = promo.type === 'percent';

    // Процентному промокоду нужна сумма пополнения
    if (isPercent && !hasDeposit) {
      await cancelActivation();
      return res.status(400).json({
        message: `Этот промокод даёт +${promo.amount}% к пополнению. Введите сумму пополнения и нажмите «Применить»`
      });
    }

    // Считаем, сколько зачислить:
    // fixed   — только бонус (сумма пополнения, если передана, игнорируется)
    // percent — пополнение + процент от него (округление вниз)
    const deposited = isPercent ? depositAmount : 0;
    const bonus = isPercent ? Math.floor(depositAmount * promo.amount / 100) : promo.amount;

    const user = await User.findByIdAndUpdate(
      req.user.id,
      { $inc: { balance: deposited + bonus } },
      { returnDocument: 'after' }
    );

    if (!user) {
      await cancelActivation();
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    // Процентный промокод — это две операции: само пополнение и бонус к нему
    if (isPercent) {
      await logTransaction({
        userId: user._id,
        type: 'deposit',
        amount: deposited,
        balanceAfter: user.balance - bonus,
        description: 'Пополнение баланса'
      });
    }
    await logTransaction({
      userId: user._id,
      type: 'promo',
      amount: bonus,
      balanceAfter: user.balance,
      description: `Промокод ${promo.code}${isPercent ? ` (+${promo.amount}%)` : ''}`
    });

    const format = (value) => value.toLocaleString('ru-RU');
    res.json({
      message: isPercent
        ? `Баланс пополнен на ${format(deposited)} ₽, бонус по промокоду: +${format(bonus)} ₽ (${promo.amount}%)`
        : `Промокод активирован: +${format(bonus)} ₽`,
      type: promo.type,
      deposited,
      bonus,
      balance: user.balance
    });
  } catch (err) {
    console.error('Ошибка активации промокода:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/promo — список промокодов (только админ) ----------
router.get('/', verifyToken, isAdmin, async (req, res) => {
  try {
    const promos = await PromoCode.find().sort({ createdAt: -1 });

    res.json(promos.map((promo) => ({
      id: promo._id,
      code: promo.code,
      type: promo.type || 'fixed',
      amount: promo.amount,
      maxUses: promo.maxUses,
      usedCount: promo.usedBy.length,
      createdAt: promo.createdAt
    })));
  } catch (err) {
    console.error('Ошибка загрузки промокодов:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/promo — создать промокод (только админ) ----------
router.post('/', verifyToken, isAdmin, async (req, res) => {
  try {
    const { error, data } = validatePromoData(req.body);
    if (error) {
      return res.status(400).json({ message: error });
    }

    await PromoCode.create(data);
    await logAdminAction(req, 'promo.create', data.code, {
      snapshot: pick(data, AUDIT_FIELDS.promo)
    });
    res.status(201).json({ message: 'Промокод создан' });
  } catch (err) {
    // Сработал уникальный индекс — такой код уже есть
    if (err.code === 11000) {
      return res.status(400).json({ message: 'Такой промокод уже существует' });
    }
    console.error('Ошибка создания промокода:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- PUT /api/promo/:id — изменить промокод (только админ) ----------
router.put('/:id', verifyToken, isAdmin, async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор промокода' });
    }

    const { error, data } = validatePromoData(req.body);
    if (error) {
      return res.status(400).json({ message: error });
    }

    // Список активировавших (usedBy) не трогаем — меняются только код, тип, бонус и лимит
    // Запоминаем промокод до изменения — для журнала действий
    const previous = await PromoCode.findById(req.params.id);
    const promo = await PromoCode.findByIdAndUpdate(req.params.id, data, {
      returnDocument: 'after',
      runValidators: true
    });

    if (!promo) {
      return res.status(404).json({ message: 'Промокод не найден' });
    }
    await logAdminAction(req, 'promo.update', promo.code, {
      changes: previous ? diff(previous, promo, AUDIT_FIELDS.promo) : []
    });
    res.json({ message: 'Промокод обновлён' });
  } catch (err) {
    // Новый код совпал с уже существующим
    if (err.code === 11000) {
      return res.status(400).json({ message: 'Такой промокод уже существует' });
    }
    console.error('Ошибка изменения промокода:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- DELETE /api/promo/:id — удалить промокод (только админ) ----------
router.delete('/:id', verifyToken, isAdmin, async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор промокода' });
    }

    const promo = await PromoCode.findByIdAndDelete(req.params.id);
    if (!promo) {
      return res.status(404).json({ message: 'Промокод не найден' });
    }
    await logAdminAction(req, 'promo.delete', promo.code, {
      snapshot: { ...pick(promo, AUDIT_FIELDS.promo), usedCount: promo.usedBy.length }
    });
    res.json({ message: 'Промокод удалён' });
  } catch (err) {
    console.error('Ошибка удаления промокода:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

module.exports = router;